import SwiftUI
import GameController

// MARK: - Botones físicos del mando (nombres neutros, posición Xbox)

enum PadKey: String, CaseIterable, Codable {
    case a, b, x, y, l1, r1, l2, r2, l3, r3, menu, options, up, down, left, right
    var title: String {
        switch self {
        case .a: "Botón inferior"; case .b: "Botón derecho"; case .x: "Botón izquierdo"; case .y: "Botón superior"
        case .l1: "L1 / LB"; case .r1: "R1 / RB"; case .l2: "L2 / LT"; case .r2: "R2 / RT"
        case .l3: "Stick izq. (clic)"; case .r3: "Stick der. (clic)"; case .menu: "Menú / Start"; case .options: "Opciones / Select"
        case .up: "Cruceta ↑"; case .down: "Cruceta ↓"; case .left: "Cruceta ←"; case .right: "Cruceta →"
        }
    }
    func pressed(_ g: GCExtendedGamepad) -> Bool {
        switch self {
        case .a: g.buttonA.isPressed; case .b: g.buttonB.isPressed; case .x: g.buttonX.isPressed; case .y: g.buttonY.isPressed
        case .l1: g.leftShoulder.isPressed; case .r1: g.rightShoulder.isPressed
        case .l2: g.leftTrigger.isPressed; case .r2: g.rightTrigger.isPressed
        case .l3: g.leftThumbstickButton?.isPressed ?? false; case .r3: g.rightThumbstickButton?.isPressed ?? false
        case .menu: g.buttonMenu.isPressed; case .options: g.buttonOptions?.isPressed ?? false
        case .up: g.dpad.up.isPressed || g.leftThumbstick.up.value > 0.5
        case .down: g.dpad.down.isPressed || g.leftThumbstick.down.value > 0.5
        case .left: g.dpad.left.isPressed || g.leftThumbstick.left.value > 0.5
        case .right: g.dpad.right.isPressed || g.leftThumbstick.right.value > 0.5
        }
    }
}

extension Pad {
    var title: String {
        switch self {
        case .a: "A"; case .b: "B"; case .x: "X"; case .y: "Y"; case .l: "L"; case .r: "R"
        case .select: "Select"; case .start: "Start"; case .up: "Arriba"; case .down: "Abajo"; case .left: "Izquierda"; case .right: "Derecha"
        case .l2: "Z / L2"; case .r2: "R2"; case .l3: "L3"; case .r3: "R3"
        case .cUp: "C ↑"; case .cDown: "C ↓"; case .cLeft: "C ←"; case .cRight: "C →"
        }
    }
    static let configurable: [Pad] = [.a, .b, .x, .y, .l, .r, .l2, .select, .start]
}

typealias PadMap = [String: Int]   // PadKey.rawValue → Pad.rawValue (-1 = ninguno)

enum PadPreset: String, CaseIterable {
    case positional = "Posicional (A a la derecha)"
    case label = "Por letra (Xbox / PlayStation)"
    func map() -> PadMap {
        var m: PadMap = [
            "l1": Int(Pad.l.rawValue), "r1": Int(Pad.r.rawValue), "l2": Int(Pad.l2.rawValue), "r2": Int(Pad.r.rawValue),
            "menu": Int(Pad.start.rawValue), "options": Int(Pad.select.rawValue), "l3": -1, "r3": -1,
            "up": Int(Pad.up.rawValue), "down": Int(Pad.down.rawValue), "left": Int(Pad.left.rawValue), "right": Int(Pad.right.rawValue)]
        switch self {
        case .positional: // la posición manda: inferior=B, derecho=A, izquierdo=Y, superior=X
            m["a"] = Int(Pad.b.rawValue); m["b"] = Int(Pad.a.rawValue); m["x"] = Int(Pad.y.rawValue); m["y"] = Int(Pad.x.rawValue)
        case .label:      // la letra manda: A=A, B=B, X=X, Y=Y
            m["a"] = Int(Pad.a.rawValue); m["b"] = Int(Pad.b.rawValue); m["x"] = Int(Pad.x.rawValue); m["y"] = Int(Pad.y.rawValue)
        }
        return m
    }
}

// MARK: - Preferencias

final class ControlPrefs: ObservableObject {
    static let shared = ControlPrefs()
    private let d = UserDefaults.standard
    @Published var opacity: Double { didSet { d.set(opacity, forKey: "cp.opacity") } }
    @Published var scale: Double { didSet { d.set(scale, forKey: "cp.scale") } }
    @Published var haptics: Bool { didSet { d.set(haptics, forKey: "cp.haptics") } }
    @Published var hideWithPad: Bool { didSet { d.set(hideWithPad, forKey: "cp.hide") } }
    @Published var touchMap: [String: Int] { didSet { d.set(try? JSONEncoder().encode(touchMap), forKey: "cp.touchMap") } }
    @Published var padMaps: [String: PadMap] { didSet { d.set(try? JSONEncoder().encode(padMaps), forKey: "cp.padMaps") } }
    @Published var padConnected = false
    var touchHidden: Bool { hideWithPad && padConnected }

    init() {
        opacity = d.object(forKey: "cp.opacity") as? Double ?? 1
        scale = d.object(forKey: "cp.scale") as? Double ?? 1
        haptics = d.object(forKey: "cp.haptics") as? Bool ?? true
        hideWithPad = d.object(forKey: "cp.hide") as? Bool ?? true
        touchMap = (d.data(forKey: "cp.touchMap")).flatMap { try? JSONDecoder().decode([String: Int].self, from: $0) } ?? [:]
        padMaps = (d.data(forKey: "cp.padMaps")).flatMap { try? JSONDecoder().decode([String: PadMap].self, from: $0) } ?? [:]
    }
    func touchPad(_ id: String, default p: Pad) -> Pad { touchMap[id].flatMap { Pad(rawValue: UInt32($0)) } ?? p }

    static func id(_ c: GCController) -> String { (c.vendorName ?? "Mando") + "|" + (c.productCategory) }
    func map(forID id: String) -> PadMap { padMaps[id] ?? padMaps["default"] ?? PadPreset.positional.map() }
    func setMap(_ m: PadMap, forID id: String) { padMaps[id] = m }
    func reset(forID id: String) { padMaps[id] = nil }
}

// MARK: - Pantalla de ajustes

struct ControlSettingsView: View {
    @AppStorage("cp.skin") private var skinRaw = SkinID.auto.rawValue
    @AppStorage("cp.landFull") private var landFull = true
    @AppStorage("cp.stretch") private var stretch = true
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var prefs = ControlPrefs.shared
    @State private var pads: [GCController] = GCController.controllers()

    var body: some View {
        NavigationStack {
            Form {
                // 1. Apariencia
                Section {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(SkinID.allCases) { id in
                                Button { skinRaw = id.rawValue; UISelectionFeedbackGenerator().selectionChanged() } label: { SkinChip(id: id, selected: skinRaw == id.rawValue) }.buttonStyle(.plain)
                            }
                        }.padding(.vertical, 6)
                    }
                    .listRowInsets(EdgeInsets(top: 4, leading: 12, bottom: 4, trailing: 12))
                    VStack(alignment: .leading, spacing: 8) {
                        SettingLabel("En horizontal", icon: "rectangle.landscape.rotate", color: .purple)
                        Picker("En horizontal", selection: $landFull) {
                            Text("Pantalla completa").tag(true)
                            Text("Con skin").tag(false)
                        }.pickerStyle(.segmented).labelsHidden()
                    }.padding(.vertical, 2)
                    if landFull {
                        Toggle(isOn: $stretch) { SettingLabel("Estirar a todo el ancho", icon: "arrow.left.and.right", color: .mint) }
                    }
                } header: { Text("Apariencia") }
                  footer: { Text(landFull ? stretch ? "Horizontal: el juego llena toda la pantalla y los botones quedan traslúcidos encima." : "Horizontal: el juego a todo lo alto, con su proporción original y botones traslúcidos encima." : "Horizontal: la consola con su carcasa y los botones a los lados.") }

                // 2. Controles táctiles
                Section("Controles táctiles") {
                    HStack(spacing: 12) {
                        SettingLabel("Opacidad", icon: "circle.lefthalf.filled", color: .blue).frame(width: 130, alignment: .leading)
                        Slider(value: $prefs.opacity, in: 0.25...1)
                    }
                    HStack(spacing: 12) {
                        SettingLabel("Tamaño", icon: "arrow.up.left.and.arrow.down.right", color: .teal).frame(width: 130, alignment: .leading)
                        Slider(value: $prefs.scale, in: 0.7...1.4)
                    }
                    Toggle(isOn: $prefs.haptics) { SettingLabel("Vibración", icon: "iphone.radiowaves.left.and.right", color: .orange) }
                    NavigationLink { TouchRemapView() } label: { SettingLabel("Reasignar botones", icon: "arrow.left.arrow.right", color: .pink) }
                }

                // 3. Mando Bluetooth
                Section {
                    HStack {
                        SettingLabel(pads.isEmpty ? "Sin mando conectado" : (pads.first?.vendorName ?? "Mando"), icon: "gamecontroller.fill", color: pads.isEmpty ? .gray : .green)
                        Spacer()
                        if !pads.isEmpty { Text("Conectado").font(.footnote).foregroundStyle(.green) }
                    }
                    Toggle(isOn: $prefs.hideWithPad) { SettingLabel("Ocultar táctiles con mando", icon: "eye.slash", color: .indigo) }
                    NavigationLink { PadSettingsView() } label: { SettingLabel("Configurar mando", icon: "slider.horizontal.3", color: .cyan) }
                } header: { Text("Mando Bluetooth") }
                  footer: { if pads.isEmpty { Text("Conecta tu mando en Ajustes › Bluetooth (Xbox, PlayStation, Switch Pro o MFi).") } }

                // 4. Ayuda
                Section("Ayuda") {
                    NavigationLink { HelpView() } label: { SettingLabel("Cómo usar ARIAemu 3D", icon: "questionmark.circle.fill", color: .orange) }
                }

                // 5. Legal
                Section {
                    NavigationLink { LegalContent() } label: { SettingLabel("Uso responsable y privacidad", icon: "checkmark.shield.fill", color: .gray) }
                }
            }
            .navigationTitle("Opciones")
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Listo") { dismiss() }.fontWeight(.semibold) } }
            .onAppear { pads = GCController.controllers() }
            .onReceive(NotificationCenter.default.publisher(for: .GCControllerDidConnect)) { _ in pads = GCController.controllers() }
            .onReceive(NotificationCenter.default.publisher(for: .GCControllerDidDisconnect)) { _ in pads = GCController.controllers() }
        }
    }
}

/// Fila estilo Ajustes de iOS: ícono en cuadro de color + texto
struct SettingLabel: View {
    let title: String; let icon: String; let color: Color
    init(_ title: String, icon: String, color: Color) { self.title = title; self.icon = icon; self.color = color }
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon).font(.system(size: 14, weight: .semibold)).foregroundStyle(.white)
                .frame(width: 28, height: 28).background(color.gradient, in: RoundedRectangle(cornerRadius: 7))
            Text(title)
        }
    }
}

// MARK: - Reasignar botones táctiles

struct TouchRemapView: View {
    @ObservedObject private var prefs = ControlPrefs.shared
    var body: some View {
        Form {
            Section {
                Button { swap(.a, .b) } label: { SettingLabel("Intercambiar A ↔ B", icon: "arrow.left.arrow.right", color: .red) }
                Button { swap(.x, .y) } label: { SettingLabel("Intercambiar X ↔ Y", icon: "arrow.left.arrow.right", color: .blue) }
            }
            Section("Cada botón hace…") {
                ForEach(["A", "B", "X", "Y", "L", "R", "SELECT", "START"], id: \.self) { id in
                    let def = Pad.configurable.first { $0.title.uppercased() == id }!
                    Picker(id, selection: Binding(get: { Int(prefs.touchPad(id, default: def).rawValue) }, set: { prefs.touchMap[id] = $0 })) {
                        ForEach(Pad.configurable, id: \.self) { p in Text(p.title).tag(Int(p.rawValue)) }
                    }
                }
            }
            Section {
                Button("Restaurar táctiles", role: .destructive) { prefs.touchMap = [:]; prefs.opacity = 1; prefs.scale = 1 }
            }
        }
        .navigationTitle("Botones táctiles").navigationBarTitleDisplayMode(.inline)
    }
    private func swap(_ a: Pad, _ b: Pad) {
        let ia = a.title.uppercased(), ib = b.title.uppercased()
        let pa = prefs.touchPad(ia, default: a), pb = prefs.touchPad(ib, default: b)
        prefs.touchMap[ia] = Int(pb.rawValue); prefs.touchMap[ib] = Int(pa.rawValue)
    }
}

// MARK: - Mando Bluetooth

struct PadSettingsView: View {
    @ObservedObject private var prefs = ControlPrefs.shared
    @State private var pads: [GCController] = GCController.controllers()
    @State private var selID = "default"
    @State private var live: UInt32 = 0
    @State private var learning: Pad?

    private var map: PadMap { prefs.map(forID: selID) }
    private func name(_ id: String) -> String { id == "default" ? "Cualquier mando" : String(id.split(separator: "|").first ?? "Mando") }

    var body: some View {
        Form {
            Section {
                Picker("Mando", selection: $selID) {
                    Text(name("default")).tag("default")
                    ForEach(pads, id: \.self) { c in Text(c.vendorName ?? "Mando").tag(ControlPrefs.id(c)) }
                }
                ForEach(PadPreset.allCases, id: \.self) { p in
                    Button { prefs.setMap(p.map(), forID: selID) } label: {
                        SettingLabel(p.rawValue, icon: p == .positional ? "square.grid.2x2" : "textformat", color: p == .positional ? .green : .blue)
                    }
                }
            } header: { Text("Distribución") }
              footer: { Text("Clásica: B abajo y A a la derecha. «Por letra»: A del mando = A del juego (útil con Xbox/PlayStation).") }

            Section("Prueba en vivo") {
                HStack(spacing: 6) {
                    ForEach(Pad.configurable + [.up, .down, .left, .right], id: \.self) { p in
                        Text(String(p.title.prefix(2))).font(.caption2.weight(.bold)).frame(width: 26, height: 26)
                            .background(live & p.mask != 0 ? Color.green : Color.gray.opacity(0.25), in: Circle())
                    }
                }.frame(maxWidth: .infinity)
            }

            Section {
                ForEach(Pad.configurable, id: \.self) { p in
                    HStack {
                        Text(p.title).font(.body.weight(.semibold)).frame(width: 70, alignment: .leading)
                        Text(keys(for: p)).font(.footnote).foregroundStyle(.secondary).lineLimit(1)
                        Spacer()
                        Button(learning == p ? "Pulsa…" : "Asignar") { startLearn(p) }.buttonStyle(.bordered).controlSize(.small)
                            .tint(learning == p ? .orange : .accentColor)
                    }
                }
            } header: { Text("Asignar botones") } footer: { Text("Toca Asignar y luego pulsa el botón en tu mando.") }

            Section {
                DisclosureGroup("Avanzado: cada botón del mando") {
                    ForEach(PadKey.allCases, id: \.self) { k in
                        Picker(k.title, selection: Binding(get: { map[k.rawValue] ?? -1 }, set: { v in var m = map; m[k.rawValue] = v; prefs.setMap(m, forID: selID) })) {
                            Text("Ninguno").tag(-1)
                            ForEach(Pad.configurable + [.up, .down, .left, .right], id: \.self) { p in Text(p.title).tag(Int(p.rawValue)) }
                        }
                    }
                }
                Button("Restaurar este mando", role: .destructive) { prefs.reset(forID: selID) }
            }
        }
        .navigationTitle("Mando").navigationBarTitleDisplayMode(.inline)
        .onAppear {
            PadInput.shared.start()
            PadInput.shared.onLive = { live = $0 }
            pads = GCController.controllers()
            if let c = pads.first { selID = ControlPrefs.id(c) }
        }
        .onDisappear { PadInput.shared.onLive = nil; PadInput.shared.learn = nil }
        .onReceive(NotificationCenter.default.publisher(for: .GCControllerDidConnect)) { _ in pads = GCController.controllers() }
        .onReceive(NotificationCenter.default.publisher(for: .GCControllerDidDisconnect)) { _ in pads = GCController.controllers() }
    }

    private func keys(for p: Pad) -> String {
        let ks = PadKey.allCases.filter { map[$0.rawValue] == Int(p.rawValue) }.map { $0.title }
        return ks.isEmpty ? "—" : ks.prefix(2).joined(separator: ", ")
    }
    private func startLearn(_ p: Pad) {
        learning = p
        PadInput.shared.learn = { key in
            var m = map
            for k in PadKey.allCases where ![.up, .down, .left, .right].contains(k) && m[k.rawValue] == Int(p.rawValue) { m[k.rawValue] = -1 }
            m[key.rawValue] = Int(p.rawValue)
            prefs.setMap(m, forID: selID); learning = nil
        }
    }
}


// MARK: - Ayuda

struct HelpView: View {
    var body: some View {
        List {
            Section("Añadir juegos") {
                help("folder.fill", .blue, "Carpeta fija", "Añadir › Elegir carpeta fija. Deja tus juegos en esa carpeta (Archivos o iCloud Drive) y se añaden solos cada vez que abres la app.")
                help("square.and.arrow.down.fill", .teal, "Abrir con ARIAemu 3D", "En Archivos, Safari, Mail o WhatsApp toca Compartir › ARIAemu sobre un .gb, .gbc, .gba, .sfc, .zip o .7z.")
                help("globe", .indigo, "Buscar", "Busca páginas desde la app, guárdalas con ★ y descarga directo a tu biblioteca.")
                help("doc.zipper", .gray, "Varias versiones", "Si un .zip trae varias versiones, la app te pregunta cuál guardar.")
            }
            Section("Carátulas") {
                help("photo.fill", .pink, "Buscar carátula", "Toca ⋯ junto a Jugar (o mantén apretada la portada) › Buscar carátula en Google. Toca la imagen y Guardar.")
            }
            Section("Jugar con otro iPhone") {
                help("person.2.fill", .green, "2 jugadores (Super Nintendo)", "Ambos abren el mismo juego. En la pausa (⋯) uno toca 2 jugadores › Invitar y el otro › Unirse. El que invita es el jugador 1.")
                help("cable.connector", .orange, "Cable link (Game Boy / Color)", "Para intercambiar y combatir entre juegos compatibles. Cada uno abre su juego; en la pausa uno toca Cable link › Conectar y el otro › Buscar. Luego entren al centro de intercambio del juego.")
                help("wifi", .cyan, "Sin cables ni misma red", "Basta con estar cerca: usa Wi‑Fi directo entre equipos o Bluetooth. La primera vez permite Red local.")
            }
            Section("Durante el juego") {
                help("square.and.arrow.down.on.square", .purple, "Partidas guardadas", "En la pausa tienes 3 espacios para guardar y cargar en cualquier momento. Además, la app retoma donde quedaste.")
                help("rectangle.landscape.rotate", .mint, "Horizontal", "Gira el iPhone: elige en Opciones › Apariencia entre Pantalla completa (botones translúcidos) o Con skin.")
                help("applewatch", .red, "Apple Watch", "Tus juegos del iPhone aparecen solos en el reloj.")
            }
        }
        .navigationTitle("Cómo usar ARIAemu 3D").navigationBarTitleDisplayMode(.inline)
    }
    private func help(_ icon: String, _ color: Color, _ title: String, _ text: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon).font(.system(size: 14, weight: .semibold)).foregroundStyle(.white)
                .frame(width: 28, height: 28).background(color.gradient, in: RoundedRectangle(cornerRadius: 7))
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.subheadline.weight(.semibold))
                Text(text).font(.footnote).foregroundStyle(.secondary)
            }
        }.padding(.vertical, 2)
    }
}
