import SwiftUI
import UIKit
import QuartzCore

/// Superficie OpenGL ES donde el núcleo 3D presenta cada cuadro (sin copiar a CGImage).
final class GLLayerView: UIView {
    override class var layerClass: AnyClass { CAEAGLLayer.self }
    override init(frame: CGRect) {
        super.init(frame: frame)
        let l = layer as! CAEAGLLayer
        l.isOpaque = true
        l.drawableProperties = [kEAGLDrawablePropertyRetainedBacking: false, kEAGLDrawablePropertyColorFormat: kEAGLColorFormatRGBA8]
        backgroundColor = .black
        isUserInteractionEnabled = false
    }
    required init?(coder: NSCoder) { fatalError() }
    private var lastSize: CGSize = .zero
    override func layoutSubviews() {
        super.layoutSubviews()
        let scale = window?.screen.scale ?? UIScreen.main.scale
        layer.contentsScale = scale
        if bounds.size != lastSize, bounds.width > 1 { lastSize = bounds.size; emu_set_layer(Unmanaged.passUnretained(layer).toOpaque()) }
    }
    override func didMoveToWindow() {
        super.didMoveToWindow()
        if window == nil { emu_set_layer(nil) } else { setNeedsLayout() }
    }
}

struct GLScreen: UIViewRepresentable {
    func makeUIView(context: Context) -> GLLayerView { GLLayerView(frame: .zero) }
    func updateUIView(_ v: GLLayerView, context: Context) {}
}
