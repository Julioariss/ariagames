import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

// MARK: - Estilo gamer

enum Neon {
    static let magenta = Color(red: 1.0, green: 0.16, blue: 0.48)
    static let cyan = Color(red: 0.0, green: 0.90, blue: 1.0)
    static let violet = Color(red: 0.55, green: 0.30, blue: 1.0)
    static let void = Color(red: 0.02, green: 0.02, blue: 0.05)
    static let panel = Color(red: 0.07, green: 0.07, blue: 0.12)
    static var hero: LinearGradient { LinearGradient(colors: [magenta, violet], startPoint: .leading, endPoint: .trailing) }
}

/// Fondo oscuro con rejilla y halos de neón.
struct GamerBackground: View {
    var body: some View {
        ZStack {
            Neon.void
            RadialGradient(colors: [Neon.violet.opacity(0.45), .clear], center: .init(x: 0.15, y: 0.1), startRadius: 0, endRadius: 420)
            RadialGradient(colors: [Neon.cyan.opacity(0.22), .clear], center: .init(x: 0.95, y: 0.95), startRadius: 0, endRadius: 460)
            Canvas { ctx, size in
                var p = Path()
                let step: CGFloat = 34
                var x: CGFloat = 0; while x < size.width { p.move(to: .init(x: x, y: 0)); p.addLine(to: .init(x: x, y: size.height)); x += step }
                var y: CGFloat = 0; while y < size.height { p.move(to: .init(x: 0, y: y)); p.addLine(to: .init(x: size.width, y: y)); y += step }
                ctx.stroke(p, with: .color(.white.opacity(0.035)), lineWidth: 1)
            }
            LinearGradient(colors: [.clear, Neon.void.opacity(0.9)], startPoint: .center, endPoint: .bottom)
        }.ignoresSafeArea()
    }
}

// MARK: - Modelo

struct LibGame: Identifiable, Hashable {
    let url: URL
    var id: String { url.lastPathComponent }
    var title: String { url.deletingPathExtension().lastPathComponent }
    var ext: String { url.pathExtension.lowercased() }
    var badge: String {
        if let c = Console.from(ext: ext) { return c.short }
        return switch ext { case "gb": "GB"; case "gbc": "GBC"; case "gba": "GBA"; case "sfc", "smc", "swc", "fig": "SNES"; case "nes", "fds", "unf": "NES"; case "md", "gen", "smd", "bin": "MD"; default: ext.uppercased() }
    }
    var tint: Color {
        switch ext {
        case "gb": Color(red: 0.45, green: 0.55, blue: 0.30)
        case "gbc": Color(red: 0.84, green: 0.14, blue: 0.30)
        case "gba": Color(red: 0.36, green: 0.31, blue: 0.80)
        case "nes", "fds", "unf": Color(red: 0.72, green: 0.16, blue: 0.18)
        case "md", "gen", "smd", "bin": Color(red: 0.16, green: 0.20, blue: 0.30)
        default: Color(red: 0.20, green: 0.50, blue: 0.85)
        }
    }
    static let exts: Set<String> = Console.romExts

    /// Título sin etiquetas entre paréntesis/corchetes: "Donkey Kong (USA) (Rev 1)" -> "Donkey Kong".
    var cleanTitle: String {
        var s = title
        if let a = s.firstIndex(where: { $0 == "(" || $0 == "[" }) { s = String(s[..<a]) }
        let t = s.trimmingCharacters(in: .whitespaces)
        return t.isEmpty ? title : t
    }
    var baseKey: String { cleanTitle.lowercased().filter { $0.isLetter || $0.isNumber } + "." + ext }
    var regionScore: Int {
        let t = title.lowercased()
        var s = 0
        if t.contains("(usa") || t.contains("(u)") { s += 100 }
        else if t.contains("(world") { s += 90 }
        else if t.contains("(europe") || t.contains("(eur") || t.contains("(e)") { s += 60 }
        else if t.contains("(japan") || t.contains("(j)") { s += 20 }
        else { s += 50 }
        for bad in ["beta", "proto", "demo", "sample", "unl", "pirate", "hack", "[b", "[h"] where t.contains(bad) { s -= 60 }
        if t.contains("(rev") { s += 3 }
        return s
    }
}

final class PhoneLibrary: ObservableObject {
    static let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    static let romsDir = docs.appendingPathComponent("ROMs", isDirectory: true)
    static let coversDir = docs.appendingPathComponent("Covers", isDirectory: true)
    @Published var games: [LibGame] = []
    /// Archivo comprimido con varias versiones: el usuario elige cuál(es) guardar.
    struct ArchiveChoice: Identifiable { let id = UUID(); let archive: String; let files: [(name: String, data: Data)] }
    @Published var choice: ArchiveChoice?
    private var choiceQueue: [ArchiveChoice] = []
    func save(_ picked: [(name: String, data: Data)]) {
        var n = 0
        for f in picked where (try? f.data.write(to: Self.romsDir.appendingPathComponent(f.name), options: .atomic)) != nil { n += 1 }
        lastImport = n > 0 ? "✓ \(n) juego(s) añadidos" : "No se añadió nada"
        reload()
        nextChoice()
    }
    func nextChoice() { choice = choiceQueue.isEmpty ? nil : choiceQueue.removeFirst() }
    @Published var rev = 0 { didSet { imgCache.removeAll() } }
    private var allFiles: [LibGame] = []
    private var imgCache: [String: UIImage] = [:]
    private var missing: Set<String> = []

    static func snapURL(_ id: String) -> URL { coversDir.appendingPathComponent(id + ".snap.jpg") }
    /// Guarda la última pantalla del juego: se usa como portada cuando no elegiste una.
    static func saveSnapshot(_ img: CGImage, id: String) {
        try? UIImage(cgImage: img).jpegData(compressionQuality: 0.92)?.write(to: snapURL(id), options: .atomic)
    }
    static var played: [String: Double] { UserDefaults.standard.dictionary(forKey: "played") as? [String: Double] ?? [:] }
    static func markPlayed(_ id: String) {
        var d = played; d[id] = Date().timeIntervalSince1970
        UserDefaults.standard.set(d, forKey: "played")
    }
    /// Cuántos archivos (versiones/regiones) hay del mismo juego.
    func variants(of g: LibGame) -> [LibGame] { allFiles.filter { $0.baseKey == g.baseKey } }

    init() {
        for d in [Self.romsDir, Self.coversDir] { try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true) }
        reload()
    }
    // MARK: Carpeta fija de juegos (Archivos / iCloud Drive / USB)
    private static let folderKey = "romFolderBookmark", seenKey = "romFolderSeen"
    var folderName: String? {
        guard let b = UserDefaults.standard.data(forKey: Self.folderKey) else { return nil }
        var stale = false
        return (try? URL(resolvingBookmarkData: b, bookmarkDataIsStale: &stale))?.lastPathComponent
    }
    func setFolder(_ u: URL) {
        let ok = u.startAccessingSecurityScopedResource(); defer { if ok { u.stopAccessingSecurityScopedResource() } }
        if let b = try? u.bookmarkData(options: [], includingResourceValuesForKeys: nil, relativeTo: nil) {
            UserDefaults.standard.set(b, forKey: Self.folderKey)
            UserDefaults.standard.removeObject(forKey: Self.seenKey)
        }
        scanFolder(manual: true)
    }
    func clearFolder() { UserDefaults.standard.removeObject(forKey: Self.folderKey); UserDefaults.standard.removeObject(forKey: Self.seenKey) }
    /// Importa solo los archivos nuevos de la carpeta fija.
    @discardableResult func scanFolder(manual: Bool = false) -> Int {
        guard let b = UserDefaults.standard.data(forKey: Self.folderKey) else { return 0 }
        var stale = false
        guard let dir = try? URL(resolvingBookmarkData: b, bookmarkDataIsStale: &stale) else { return 0 }
        let ok = dir.startAccessingSecurityScopedResource(); defer { if ok { dir.stopAccessingSecurityScopedResource() } }
        if stale, let nb = try? dir.bookmarkData(options: [], includingResourceValuesForKeys: nil, relativeTo: nil) { UserDefaults.standard.set(nb, forKey: Self.folderKey) }
        var seen = Set(UserDefaults.standard.stringArray(forKey: Self.seenKey) ?? [])
        let okExt = LibGame.exts.union(["zip", "7z"])
        var items = (FileManager.default.enumerator(at: dir, includingPropertiesForKeys: [.fileSizeKey, .contentModificationDateKey], options: [])?.allObjects as? [URL]) ?? []
        if items.isEmpty { items = ((try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil)) ?? []) }
        // iCloud Drive: los archivos no descargados aparecen como ".nombre.gbc.icloud"; se piden y se toman en la próxima pasada.
        var pending = 0
        for u in items where u.pathExtension == "icloud" {
            let real = u.deletingLastPathComponent().appendingPathComponent(String(u.deletingPathExtension().lastPathComponent.dropFirst()))
            if okExt.contains(real.pathExtension.lowercased()) { try? FileManager.default.startDownloadingUbiquitousItem(at: real); pending += 1 }
        }
        var fresh: [URL] = []
        for u in items where okExt.contains(u.pathExtension.lowercased()) && !u.lastPathComponent.hasPrefix(".") {
            let v = try? u.resourceValues(forKeys: [.fileSizeKey, .contentModificationDateKey])
            let key = u.lastPathComponent + "|" + String(v?.fileSize ?? 0)
            if !seen.contains(key) { seen.insert(key); fresh.append(u) }
        }
        UserDefaults.standard.set(Array(seen), forKey: Self.seenKey)
        if !fresh.isEmpty { _ = importFiles(fresh) }
        else if pending > 0 { lastImport = "Descargando \(pending) juego(s) de iCloud… vuelve a tocar «Buscar nuevos» en unos segundos" }
        else if manual { lastImport = items.isEmpty ? "No pude leer la carpeta: vuelve a elegirla" : "La carpeta no tiene juegos nuevos" }
        return fresh.count
    }

    func reload() {
        let urls = (try? FileManager.default.contentsOfDirectory(at: Self.romsDir, includingPropertiesForKeys: nil)) ?? []
        let all = urls.filter { LibGame.exts.contains($0.pathExtension.lowercased()) }.map(LibGame.init)
        // Una sola versión por juego y consola: gana USA, luego World/Europa; se descartan Beta/Proto/Demo.
        var best: [String: LibGame] = [:]
        for g in all {
            let k = g.baseKey
            if let cur = best[k], cur.regionScore >= g.regionScore { continue }
            best[k] = g
        }
        allFiles = all
        // Primero los jugados recientemente (como en una consola), luego orden alfabético.
        let played = Self.played
        func last(_ g: LibGame) -> Double { variants(of: g).map { played[$0.id] ?? 0 }.max() ?? 0 }
        let stamp = Dictionary(uniqueKeysWithValues: best.values.map { ($0.id, last($0)) })
        games = best.values.sorted {
            let a = stamp[$0.id] ?? 0, b = stamp[$1.id] ?? 0
            if a != b { return a > b }
            return $0.cleanTitle.localizedCaseInsensitiveCompare($1.cleanTitle) == .orderedAscending
        }
        missing.removeAll(); imgCache.removeAll()
    }
    /// Importa juegos sueltos, ZIP o 7z a la biblioteca del iPhone; devuelve los archivos que también conviene enviar al reloj.
    var lastImport = ""
    @discardableResult
    func importFiles(_ urls: [URL]) -> [URL] {
        var toWatch: [URL] = [], added = 0, errs: [String] = []
        for u in urls {
            let ok = u.startAccessingSecurityScopedResource(); defer { if ok { u.stopAccessingSecurityScopedResource() } }
            guard let d = try? Data(contentsOf: u, options: .mappedIfSafe) else { errs.append(u.lastPathComponent + ": ilegible"); continue }
            let r = Archive.roms(from: d, name: u.lastPathComponent)
            if let e = r.error { errs.append(u.lastPathComponent + ": " + e); continue }
            if r.files.count > 1 {   // varias versiones dentro: preguntar
                let c = ArchiveChoice(archive: u.lastPathComponent, files: r.files.map { (name: $0.0, data: $0.1) })
                if choice == nil { choice = c } else { choiceQueue.append(c) }
                continue
            }
            for (n, bytes) in r.files where (try? bytes.write(to: Self.romsDir.appendingPathComponent(n), options: .atomic)) != nil { added += 1 }
            toWatch.append(u)
        }
        lastImport = added > 0 ? "✓ \(added) juego(s) añadidos" : (choice != nil ? "Elige qué versión guardar" : (errs.first ?? "No se añadió nada"))
        reload()
        return toWatch
    }
    func coverURL(_ g: LibGame) -> URL { Self.coversDir.appendingPathComponent(g.id + ".jpg") }
    func cover(_ g: LibGame) -> UIImage? {
        if let c = imgCache[g.id] { return c }
        if missing.contains(g.id) { return nil }
        let img = UIImage(contentsOfFile: coverURL(g).path) ?? UIImage(contentsOfFile: Self.snapURL(g.id).path)
        if let img { imgCache[g.id] = img } else { missing.insert(g.id) }
        return img
    }
    func setCover(_ data: Data, for g: LibGame) {
        guard let img = UIImage(data: data) else { return }
        let side: CGFloat = 700
        let s = min(1, side / max(img.size.width, img.size.height))
        let size = CGSize(width: img.size.width * s, height: img.size.height * s)
        let small = UIGraphicsImageRenderer(size: size).image { _ in img.draw(in: CGRect(origin: .zero, size: size)) }
        try? small.jpegData(compressionQuality: 0.85)?.write(to: coverURL(g), options: .atomic)
        missing.remove(g.id); rev += 1
    }
    func delete(_ g: LibGame) {
        // Borra todas las versiones del juego (las ocultas también), su portada y captura.
        for v in variants(of: g) {
            try? FileManager.default.removeItem(at: v.url)
            try? FileManager.default.removeItem(at: coverURL(v))
            try? FileManager.default.removeItem(at: Self.snapURL(v.id))
        }
        reload()
    }
}

// MARK: - Tarjeta

struct GameTile: View {
    let game: LibGame
    let cover: UIImage?
    let size: CGFloat
    let selected: Bool

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            if let c = cover {
                Image(uiImage: c).resizable().interpolation(c.size.width < 600 ? .none : .high).scaledToFill().frame(width: size, height: size).clipped()
            } else {
                LinearGradient(colors: [game.tint, game.tint.opacity(0.55), Color.black.opacity(0.8)], startPoint: .topLeading, endPoint: .bottomTrailing)
                Text(String(game.title.prefix(2)).uppercased())
                    .font(.system(size: size * 0.42, weight: .black, design: .rounded)).foregroundStyle(.white.opacity(0.22))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                Text(game.cleanTitle).font(.system(size: size * 0.09, weight: .bold)).foregroundStyle(.white).lineLimit(2)
                    .padding(size * 0.07)
            }
            Text(game.badge).font(.system(size: size * 0.07, weight: .heavy, design: .rounded)).padding(.horizontal, 8).padding(.vertical, 3)
                .background(.black.opacity(0.55), in: Capsule()).foregroundStyle(.white).padding(8)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.10, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: size * 0.10, style: .continuous)
                .strokeBorder(LinearGradient(colors: [Neon.cyan, Neon.magenta], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: selected ? 4 : 0)
        }
        .shadow(color: selected ? Neon.magenta.opacity(0.55) : .black.opacity(0.4), radius: selected ? 26 : 6, y: selected ? 6 : 3)
        .scaleEffect(selected ? 1.0 : 0.88)
        .animation(.spring(response: 0.35, dampingFraction: 0.75), value: selected)
    }
}

// MARK: - Menú principal

struct Launcher: View {
    @StateObject private var lib = PhoneLibrary()
    @Environment(\.horizontalSizeClass) private var hs
    @Environment(\.colorScheme) private var scheme
    @State private var sel: String?
    @State private var scrollW: CGFloat = 0   // ancho real del carrusel (en horizontal el notch lo achica)
    @State private var adding = false
    @State private var pickItem: PhotosPickerItem?
    @State private var coverTarget: LibGame?
    @State private var showCoverPicker = false
    @State private var coverSearch: LibGame?
    @State private var showLegal = false
    @State private var showFinder = false
    @State private var showControls = false
    @State private var playing: LibGame?
    @State private var openedMsg: String?
    @State private var addMenu = false
    @State private var pickFolder = false
    @Environment(\.scenePhase) private var phase
    @State private var confirmDelete: LibGame?
    @ObservedObject private var prefs = ControlPrefs.shared
    @Environment(\.openURL) private var openURL
    @State private var lastNav: UInt32 = 0
    @State private var filter: Console?
    @State private var query = ""
    @State private var searching = false
    @State private var box: CGSize = UIScreen.main.bounds.size
    @FocusState private var searchFocus: Bool

    /// La tarjeta se adapta al ancho y al alto (también en horizontal).
    private var tile: CGFloat {
        // Reserva lo que ocupan barra, chips, info y dock: la tarjeta nunca empuja los botones fuera de pantalla.
        let chipsH: CGFloat = (consoles.count > 1 || !query.isEmpty) ? 50 : 0
        let reserved: CGFloat = (compact ? 175 : 390) + chipsH
        return max(96, min(box.width * (hs == .regular ? 0.40 : 0.56), box.height * 0.40, box.height - reserved, 420))
    }
    private var consoles: [Console] { Console.allCases.filter { c in lib.games.contains { c.exts.contains($0.ext) } } }
    private var shown: [LibGame] {
        let q = query.trimmingCharacters(in: .whitespaces)
        return lib.games.filter { g in
            (filter == nil || filter!.exts.contains(g.ext)) && (q.isEmpty || g.cleanTitle.localizedCaseInsensitiveContains(q))
        }
    }
    private var current: LibGame? { shown.first { $0.id == sel } ?? shown.first }
    /// iPhone en horizontal: poco alto, así que el menú se compacta.
    private var compact: Bool { box.height < 600 || (box.width > box.height && box.height < 700) }

    var body: some View {
        ZStack {
            background
            VStack(spacing: 0) {
                topBar.padding(.horizontal, 22).padding(.top, 8)
                if consoles.count > 1 || !query.isEmpty { chips.padding(.top, 10) }
                Spacer(minLength: 4)
                carousel
                Group {
                    if compact {
                        HStack(spacing: 20) { info; Rectangle().fill(.white.opacity(0.15)).frame(width: 1, height: 40); miniDock.fixedSize().layoutPriority(2) }
                    } else { info }
                }.frame(height: compact ? 62 : 150).padding(.horizontal, 24).padding(.bottom, compact ? 10 : 0)
                Spacer(minLength: compact ? 0 : 8)
                if !compact { dock.padding(.bottom, 14) }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .background(GeometryReader { g in Color.clear.onAppear { box = g.size }.onChange(of: g.size) { _, n in box = n } })
        .fileImporter(isPresented: Binding(get: { adding || pickFolder }, set: { if !$0 { adding = false; pickFolder = false } }),
                      allowedContentTypes: pickFolder ? [.folder] : [.zip, UTType("org.7-zip.7z-archive") ?? .archive, .data],
                      allowsMultipleSelection: !pickFolder) { r in
            guard case .success(let urls) = r else { return }
            if pickFolder, let u = urls.first { lib.setFolder(u); toast(lib.lastImport) } else { lib.importFiles(urls) }
            pickFolder = false; adding = false
        }
        .onOpenURL { u in
            // "Abrir con ARIAemu 3D" desde Archivos, Safari, Mail, WhatsApp, AirDrop…
            let before = Set(lib.games.map(\.id))
            _ = lib.importFiles([u])
            if let g = lib.games.first(where: { !before.contains($0.id) }) { withAnimation { sel = g.id } }
            openedMsg = lib.lastImport
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) { openedMsg = nil }
        }
        .overlay(alignment: .top) {
            if let m = openedMsg {
                Text(m).font(.footnote.weight(.semibold)).foregroundStyle(.white).padding(.horizontal, 16).padding(.vertical, 9)
                    .background(.black.opacity(0.8), in: Capsule()).padding(.top, 10).transition(.move(edge: .top).combined(with: .opacity))
            }
        }
        .confirmationDialog("Añadir juegos", isPresented: $addMenu, titleVisibility: .visible) {
            if let f = lib.folderName {
                Button("Buscar nuevos en «\(f)»") { lib.scanFolder(manual: true); toast(lib.lastImport) }
                Button("Cambiar carpeta fija") { pickFolder = true }
            } else {
                Button("Elegir carpeta fija de juegos") { pickFolder = true }
            }
            Button("Elegir archivos") { adding = true }
            if lib.folderName != nil { Button("Quitar carpeta fija", role: .destructive) { lib.clearFolder() } }
        } message: {
            Text(lib.folderName == nil ? "Elige una carpeta (Archivos, iCloud Drive o Descargas) y ARIAemu tomará solo los juegos nuevos que dejes ahí." : "Los juegos nuevos de tu carpeta se añaden solos al abrir la app.")
        }
        .onChange(of: phase) { _, p in if p == .active, lib.scanFolder() > 0 { toast(lib.lastImport) } }
.photosPicker(isPresented: $showCoverPicker, selection: $pickItem, matching: .images)
        .onChange(of: pickItem) { _, item in
            guard let item, let g = coverTarget else { return }
            Task { if let d = try? await item.loadTransferable(type: Data.self) { await MainActor.run { lib.setCover(d, for: g) } }; pickItem = nil }
        }
        .alert("¿Eliminar \(confirmDelete?.cleanTitle ?? "")?", isPresented: Binding(get: { confirmDelete != nil }, set: { if !$0 { confirmDelete = nil } })) {
            Button("Eliminar", role: .destructive) { if let g = confirmDelete { lib.delete(g) }; confirmDelete = nil }
            Button("Cancelar", role: .cancel) { confirmDelete = nil }
        } message: {
            let n = confirmDelete.map { lib.variants(of: $0).count } ?? 1
            Text(n > 1 ? "Se borrarán sus \(n) versiones y la partida guardada se conserva." : "La partida guardada se conserva.")
        }
        .fullScreenCover(isPresented: $showFinder) { WebFinderView(lib: lib).preferredColorScheme(.dark).tint(Neon.cyan) }
        .sheet(item: Binding(get: { showFinder ? nil : lib.choice }, set: { _ in })) { c in
            VersionPicker(choice: c) { lib.save($0) }.preferredColorScheme(.dark).tint(Neon.cyan)
        }
        .sheet(item: $coverSearch) { g in CoverSearchView(title: g.cleanTitle) { d in lib.setCover(d, for: g) }.preferredColorScheme(.dark).tint(Neon.cyan) }
        .sheet(isPresented: $showLegal) { LegalSheet().preferredColorScheme(.dark).tint(Neon.cyan) }
        .sheet(isPresented: $showControls) { ControlSettingsView().preferredColorScheme(.dark).tint(Neon.cyan) }
        .preferredColorScheme(.dark)
        .tint(Neon.cyan)
        .fullScreenCover(item: $playing, onDismiss: {
            // El juego recién usado pasa al principio, con su última pantalla como portada.
            let id = UserDefaults.standard.string(forKey: "lastPlayedID")
            lib.reload(); lib.rev += 1
            sel = nil
            DispatchQueue.main.async { withAnimation { sel = id ?? shown.first?.id } }
        }) { g in PhoneGameView(game: g) }
        .onAppear { if CommandLine.arguments.contains("-menuland"), let sc = UIApplication.shared.connectedScenes.first as? UIWindowScene { sc.requestGeometryUpdate(.iOS(interfaceOrientations: .landscapeRight)) { _ in } }; PadInput.shared.start(); PadInput.shared.nav = { padNav($0) }
            if CommandLine.arguments.contains("-controls") { showControls = true }
            #if DEBUG
            if CommandLine.arguments.contains("-importzip") { DispatchQueue.main.asyncAfter(deadline: .now() + 1) { lib.importFiles([Library.docs.appendingPathComponent("multi.zip")]) } }
            if CommandLine.arguments.contains("-demo") {
                Timer.scheduledTimer(withTimeInterval: 1.1, repeats: true) { _ in
                    let g = shown; guard !g.isEmpty else { return }
                    let i = (g.firstIndex { $0.id == current?.id } ?? 0) + 1
                    withAnimation(.spring(response: 0.45, dampingFraction: 0.8)) { sel = g[i % g.count].id }
                }
            }
            #endif
            if let i = CommandLine.arguments.firstIndex(of: "-autoplay"), i + 1 < CommandLine.arguments.count { playing = lib.games.first { $0.id == CommandLine.arguments[i + 1] } }
        }
    }

    private func toast(_ m: String) {
        openedMsg = m
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) { if openedMsg == m { openedMsg = nil } }
    }

    private var background: some View {
        GamerBackground()
    }

    private var topBar: some View {
        HStack {
            HStack(spacing: 0) {
                Text("ARIA").foregroundStyle(Neon.hero)
                Text("emu 3D").foregroundStyle(.white)
            }
            .font(.system(size: 28, weight: .black, design: .rounded).width(.condensed).italic())
            .shadow(color: Neon.magenta.opacity(0.6), radius: 10)
            if searching {
                HStack(spacing: 6) {
                    Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                    TextField("Buscar juego", text: $query).focused($searchFocus).submitLabel(.search).autocorrectionDisabled()
                    Button { query = ""; searching = false; searchFocus = false } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }
                }
                .font(.subheadline).padding(.horizontal, 12).padding(.vertical, 8).background(.thinMaterial, in: Capsule())
            } else {
                Spacer()
                Text("\(shown.count) \(shown.count == 1 ? "juego" : "juegos")").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                Button { searching = true; searchFocus = true } label: {
                    Image(systemName: "magnifyingglass").font(.system(size: 16, weight: .bold)).frame(width: 38, height: 38).background(.thinMaterial, in: Circle())
                }.buttonStyle(.plain)
            }
            if prefs.padConnected { Image(systemName: "gamecontroller.fill").font(.system(size: 18, weight: .semibold)).foregroundStyle(.secondary) }
            if compact {
                ForEach([("plus", 0), ("gamecontroller.fill", 1), ("info.circle", 2)], id: \.1) { icon, k in
                    Button { if k == 0 { adding = true } else if k == 1 { showControls = true } else { showLegal = true } } label: {
                        Image(systemName: icon).font(.system(size: 15, weight: .bold)).frame(width: 38, height: 38).background(.thinMaterial, in: Circle())
                    }.buttonStyle(.plain)
                }
            }
        }
    }

    private var chips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                chip("Todos", nil)
                ForEach(consoles, id: \.self) { c in chip(c.short, c) }
            }.padding(.horizontal, 22)
        }
    }
    private func chip(_ t: String, _ c: Console?) -> some View {
        let on = filter == c
        return Button { withAnimation(.snappy) { filter = c; sel = nil } } label: {
            Text(t).font(.system(size: 12, weight: .heavy, design: .monospaced)).tracking(1)
                .padding(.horizontal, 14).padding(.vertical, 7)
                .foregroundStyle(on ? Color.white : Color.primary)
                .background {
                    if on { Capsule().fill(Neon.hero).shadow(color: Neon.magenta.opacity(0.6), radius: 8) } else { Capsule().fill(Neon.panel.opacity(0.8)).overlay(Capsule().stroke(.white.opacity(0.15), lineWidth: 1)) }
                }
        }.buttonStyle(.plain)
    }
    /// L / R del mando cambian de consola.
    private func stepFilter(_ d: Int) {
        let opts: [Console?] = [nil] + consoles.map { Optional($0) }
        guard opts.count > 1, let i = opts.firstIndex(of: filter) else { return }
        withAnimation(.snappy) { filter = opts[(i + d + opts.count) % opts.count]; sel = nil }
    }

    private func padNav(_ m: UInt32) {
        let new = m & ~lastNav; lastNav = m
        guard playing == nil, !showControls else { return }
        if new & Pad.r.mask != 0 { stepFilter(1) }
        if new & Pad.l.mask != 0 { stepFilter(-1) }
        let games = shown
        guard let cur = current, let i = games.firstIndex(where: { $0.id == cur.id }) else { return }
        if new & Pad.right.mask != 0, i + 1 < games.count { withAnimation { sel = games[i + 1].id } }
        if new & Pad.left.mask != 0, i > 0 { withAnimation { sel = games[i - 1].id } }
        if new & (Pad.a.mask | Pad.start.mask) != 0 { playing = cur }
    }

    private var carousel: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 14) {
                ForEach(shown) { g in
                    GameTile(game: g, cover: lib.cover(g), size: tile, selected: g.id == current?.id)
                        .id(g.id)
                        .onTapGesture { if g.id == current?.id { playing = g } else { withAnimation { sel = g.id } } }
                        .contextMenu {
                            Button { coverSearch = g } label: { Label("Buscar carátula en Google", systemImage: "magnifyingglass") }
                            Button { coverTarget = g; showCoverPicker = true } label: { Label("Elegir de Fotos", systemImage: "photo") }
                            Button(role: .destructive) { confirmDelete = g } label: { Label("Eliminar", systemImage: "trash") }
                        }
                }
                Button { adding = true } label: {
                    VStack(spacing: 10) { Image(systemName: "plus").font(.system(size: tile * 0.25, weight: .light)); Text("Añadir juego").font(.subheadline.weight(.semibold)) }
                        .frame(width: tile * 0.88, height: tile * 0.88)
                        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: tile * 0.09, style: .continuous))
                }.buttonStyle(.plain)
            }
            .scrollTargetLayout()
            .padding(.vertical, compact ? 10 : 22)
        }
        // El margen va en el scroll (no como padding del contenido): la tarjeta que encaja queda justo al centro
        // y esa es la seleccionada. De a una por gesto.
        .contentMargins(.horizontal, max(0, ((scrollW > 0 ? scrollW : box.width) - tile) / 2), for: .scrollContent)
        .onGeometryChange(for: CGFloat.self) { $0.size.width } action: { scrollW = $0 }
        .scrollTargetBehavior(.viewAligned(limitBehavior: .alwaysByOne))
        .scrollPosition(id: $sel, anchor: .center)
        .sensoryFeedback(.selection, trigger: sel)
        .frame(height: tile + (compact ? 24 : 56))
    }

    private var info: some View {
        let layout = compact ? AnyLayout(HStackLayout(spacing: 22)) : AnyLayout(VStackLayout(spacing: 16))
        return layout {
            if let g = current {
                VStack(spacing: 4) {
                    Text(g.cleanTitle).font(.system(size: hs == .regular ? 32 : 24, weight: .bold, design: .rounded)).lineLimit(compact ? 1 : 2).multilineTextAlignment(.center).minimumScaleFactor(0.6)
                        .frame(minWidth: compact ? 120 : nil, maxWidth: compact ? 280 : nil, minHeight: compact ? 30 : 64, maxHeight: compact ? 30 : 64)
                    Text(Console.from(ext: g.ext)?.title ?? g.ext.uppercased()).font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                }
                HStack(spacing: 14) {
                    Button { playing = g } label: {
                        Label("Jugar", systemImage: "play.fill").font(.system(size: 18, weight: .heavy, design: .rounded)).foregroundStyle(.white)
                            .lineLimit(1).fixedSize()
                            .padding(.horizontal, compact ? 28 : 38).padding(.vertical, 13)
                            .background(Neon.hero, in: Capsule())
                            .overlay(Capsule().stroke(.white.opacity(0.35), lineWidth: 1))
                            .shadow(color: Neon.magenta.opacity(0.7), radius: 16, y: 4)
                    }.buttonStyle(.plain)
                    Menu {
                        Button { coverTarget = g; showCoverPicker = true } label: { Label("Elegir de Fotos", systemImage: "photo") }
                        Button { coverSearch = g } label: { Label("Buscar carátula en Google", systemImage: "magnifyingglass") }
                        Button(role: .destructive) { confirmDelete = g } label: { Label("Eliminar", systemImage: "trash") }
                    } label: {
                        Image(systemName: "ellipsis").font(.system(size: 18, weight: .bold)).frame(width: 48, height: 48).background(.thinMaterial, in: Circle())
                    }.foregroundStyle(.primary)
                }.fixedSize().layoutPriority(2)
            } else if !lib.games.isEmpty {
                Text("Sin resultados").font(.title3.weight(.bold))
                Button("Ver todos") { query = ""; filter = nil; searching = false }.font(.footnote.weight(.semibold))
            } else {
                Text("Tu biblioteca está vacía").font(.title3.weight(.bold))
                Text("Toca “Añadir” para importar tus juegos (\(Console.romExts.sorted().map { "." + $0 }.joined(separator: " ")), .zip o .7z).")
                    .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
            }
        }
    }

    private var dock: some View {
        HStack(spacing: 22) {
            dockButton("globe", "Buscar") { showFinder = true }
            dockButton("plus", "Añadir") { addMenu = true }
            dockButton("gearshape.fill", "Opciones") { showControls = true }
            dockButton("info.circle", "Legal") { showLegal = true }
        }
    }
    /// Horizontal en iPhone: los mismos accesos, compactos, junto a "Jugar".
    private var miniDock: some View {
        HStack(spacing: 12) {
            miniButton("globe") { showFinder = true }
            miniButton("plus") { addMenu = true }
            miniButton("gearshape.fill") { showControls = true }
            miniButton("info.circle") { showLegal = true }
        }
    }
    private func miniButton(_ s: String, _ a: @escaping () -> Void) -> some View {
        Button(action: a) {
            Image(systemName: s).font(.system(size: 17, weight: .bold)).foregroundStyle(.white).frame(width: 46, height: 46)
                .background(Neon.panel.opacity(0.85), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(LinearGradient(colors: [Neon.cyan.opacity(0.8), Neon.violet.opacity(0.4)], startPoint: .top, endPoint: .bottom), lineWidth: 1.2))
        }.buttonStyle(.plain)
    }
    private func dockButton(_ s: String, _ t: String, _ a: @escaping () -> Void) -> some View {
        Button(action: a) {
            VStack(spacing: 6) {
                Image(systemName: s).font(.system(size: 22, weight: .bold)).foregroundStyle(.white).frame(width: 60, height: 60)
                    .background(Neon.panel.opacity(0.85), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(LinearGradient(colors: [Neon.cyan.opacity(0.8), Neon.violet.opacity(0.4)], startPoint: .top, endPoint: .bottom), lineWidth: 1.2))
                    .shadow(color: Neon.cyan.opacity(0.25), radius: 8)
                Text(t.uppercased()).font(.system(size: 10, weight: .heavy, design: .monospaced)).tracking(1.2).foregroundStyle(.white.opacity(0.6))
            }
        }.buttonStyle(.plain)
    }
}

struct LegalSheet: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            LegalContent()
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Listo") { dismiss() } } }
        }
    }
}

/// Uso responsable, marcas, privacidad y licencias (también en Opciones).
struct LegalContent: View {
    var body: some View {
        List {
            Section("Uso responsable") {
                Text("ARIAemu es un reproductor de juegos retro. No incluye, no vende ni distribuye juegos, y no ofrece enlaces para descargarlos.")
                Text("Usa solo juegos que te pertenezcan (copias de seguridad hechas por ti de cartuchos que posees), juegos caseros (homebrew), de dominio público o con licencia que permita su uso.")
                Text("Descargar o compartir copias de juegos comerciales sin permiso del titular puede infringir derechos de autor. Eres responsable de los archivos que cargas y de cumplir las leyes de tu país.")
            }
            Section("Marcas") {
                Text("ARIAemu es una app independiente. No está afiliada, patrocinada ni respaldada por ningún fabricante de consolas ni editor de juegos. Todas las marcas pertenecen a sus respectivos dueños.")
            }
            Section("Privacidad") {
                Text("ARIAemu no recopila datos personales, no usa publicidad, analítica ni rastreo. Tus juegos, portadas y partidas guardadas se quedan en tu dispositivo.")
                Link("Política de privacidad", destination: URL(string: "https://ariagames.dev/ariaemu-privacy.html")!)
            }
            Section("Precio") {
                Text("ARIAemu es 100 % gratis: sin compras dentro de la app, sin suscripciones y sin anuncios.")
            }
            Section("Código abierto (GPL)") {
                Text("ARIAemu 3D es software libre bajo la licencia GNU GPL versión 2 o posterior. Su código fuente completo está publicado en ariagames.dev/ariaemu3d/source.")
                Text("Mupen64Plus-Next — © equipo Mupen64Plus y libretro. GPL-2.0. Código: github.com/libretro/mupen64plus-libretro-nx")
                Text("PPSSPP — © Henrik Rydgård y colaboradores. GPL-2.0 o posterior. Código: github.com/hrydgard/ppsspp")
                Text("LZMA SDK — dominio público (Igor Pavlov).")
            }
        }
        .navigationTitle("Legal").navigationBarTitleDisplayMode(.inline)
    }
}

/// Aviso obligatorio la primera vez que se abre la app en iPhone/iPad.
struct LegalGateView: View {
    var accept: () -> Void
    var body: some View {
        VStack(spacing: 18) {
            Spacer()
            Image(systemName: "checkmark.shield.fill").font(.system(size: 58)).foregroundStyle(Neon.hero).shadow(color: Neon.magenta.opacity(0.6), radius: 14)
            Text("Antes de empezar").font(.system(size: 28, weight: .bold, design: .rounded))
            Text("ARIAemu no incluye juegos. Usa solo juegos que te pertenezcan, caseros, de dominio público o con licencia que lo permita. Tú eres responsable de los archivos que cargas.")
                .font(.body).multilineTextAlignment(.center).foregroundStyle(.secondary).padding(.horizontal, 28)
            Text("Más detalles en Opciones › Legal.").font(.footnote).foregroundStyle(.secondary)
            Spacer()
            Button(action: accept) {
                Text("Entiendo y acepto").font(.headline).foregroundStyle(.white).frame(maxWidth: 420).frame(height: 54)
                    .background(Neon.hero, in: Capsule()).shadow(color: Neon.magenta.opacity(0.6), radius: 14)
            }.padding(.horizontal, 24).padding(.bottom, 30)
        }
        .foregroundStyle(.white)
        .background(GamerBackground())
        .preferredColorScheme(.dark)
    }
}


/// Elegir versión dentro de un ZIP/7z con varios juegos.
struct VersionPicker: View {
    let choice: PhoneLibrary.ArchiveChoice
    let onSave: ([(name: String, data: Data)]) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var picked: Set<String> = []
    private var items: [(name: String, data: Data, game: LibGame)] {
        choice.files.map { ($0.name, $0.data, LibGame(url: URL(fileURLWithPath: $0.name))) }
            .sorted { $0.game.regionScore != $1.game.regionScore ? $0.game.regionScore > $1.game.regionScore : $0.name < $1.name }
    }
    var body: some View {
        NavigationStack {
            List {
                Section {
                    ForEach(items, id: \.name) { it in
                        Button {
                            if picked.contains(it.name) { picked.remove(it.name) } else { picked.insert(it.name) }
                            UISelectionFeedbackGenerator().selectionChanged()
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: picked.contains(it.name) ? "checkmark.circle.fill" : "circle")
                                    .font(.title3).foregroundStyle(picked.contains(it.name) ? Neon.cyan : .secondary)
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(it.game.cleanTitle).font(.body.weight(.semibold)).foregroundStyle(.white)
                                    Text(tags(it.game.title)).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                                }
                                Spacer()
                                Text(it.game.badge).font(.caption2.weight(.heavy)).padding(.horizontal, 7).padding(.vertical, 3)
                                    .background(it.game.tint, in: Capsule()).foregroundStyle(.white)
                            }
                        }
                    }
                } header: { Text("\(choice.files.count) versiones en \(choice.archive)") }
                  footer: { Text("Marcamos la recomendada (USA, luego Mundial/Europa). Puedes elegir más de una.") }
            }
            .navigationTitle("¿Cuál guardar?").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { onSave([]); dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button(picked.count > 1 ? "Guardar \(picked.count)" : "Guardar") {
                        onSave(items.filter { picked.contains($0.name) }.map { (name: $0.name, data: $0.data) }); dismiss()
                    }.bold().disabled(picked.isEmpty)
                }
            }
        }
        .interactiveDismissDisabled()
        .onAppear { if picked.isEmpty, let best = items.first { picked = [best.name] } }
    }
    private func tags(_ t: String) -> String {
        let parts = t.split(whereSeparator: { "()[]".contains($0) }).dropFirst().map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
        return parts.isEmpty ? "Versión única" : parts.joined(separator: " · ")
    }
}
