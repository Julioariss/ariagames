import SwiftUI
import UIKit

// MARK: - Skins estilo consola portátil (diseño original, sin marcas). Varios colores para elegir.

enum SkinID: String, CaseIterable, Identifiable {
    case auto, lime, grape, ruby, sky, carbon, pearl, neon
    var id: String { rawValue }
    var title: String {
        switch self {
        case .auto: "Automático (según consola)"
        case .lime: "Verde limón"
        case .grape: "Morado"
        case .ruby: "Colorado"
        case .sky: "Celeste"
        case .carbon: "Negro carbón"
        case .pearl: "Blanco perla"
        case .neon: "Neón gamer"
        }
    }
    static func forConsole(_ c: Console) -> SkinID { c == .psp ? .lime : .grape }
}

struct SkinTheme {
    enum Style { case brick, clam, pad, neon }
    let style: Style
    let body: [Color]       // carcasa (degradado)
    let gloss: Double       // brillo de la carcasa
    let bezel: Color
    let brand: String
    let ink: Color          // texto impreso sobre la carcasa
    let led: Color
    let dpad: Color
    let face: Color         // botones de acción
    let label: Color        // símbolo sobre el botón
    let pill: Color
    let shoulder: Color
    let stick: Color
    let cBtn: Color         // botones C (consola 64)

    static func of(_ id: SkinID, console: Console) -> SkinTheme {
        let brand = console == .psp ? "ARIA Pocket" : "ARIA 64"
        func make(_ b: [Color], gloss: Double = 0.35, ink: Color = .white.opacity(0.85), btn: Color, label: Color = .white.opacity(0.92),
                  led: Color = Color(red: 0.3, green: 1, blue: 0.5), style: Style = .pad, stick: Color? = nil) -> SkinTheme {
            .init(style: style, body: b, gloss: gloss, bezel: Color(white: 0.04), brand: brand, ink: ink, led: led, dpad: btn, face: btn, label: label,
                  pill: btn, shoulder: btn, stick: stick ?? btn, cBtn: Color(red: 1.0, green: 0.82, blue: 0.20))
        }
        switch id {
        case .auto: return of(SkinID.forConsole(console), console: console)
        case .lime:
            return make([Color(red: 0.72, green: 0.93, blue: 0.20), Color(red: 0.42, green: 0.70, blue: 0.08)], ink: Color(red: 0.12, green: 0.22, blue: 0.02).opacity(0.85),
                        btn: Color(red: 0.86, green: 0.98, blue: 0.48), label: Color(red: 0.16, green: 0.30, blue: 0.02), stick: Color(red: 0.20, green: 0.32, blue: 0.06))
        case .grape:
            return make([Color(red: 0.55, green: 0.33, blue: 0.86), Color(red: 0.31, green: 0.13, blue: 0.60)], btn: Color(red: 0.72, green: 0.56, blue: 0.98),
                        stick: Color(red: 0.18, green: 0.08, blue: 0.36))
        case .ruby:
            return make([Color(red: 0.86, green: 0.27, blue: 0.19), Color(red: 0.60, green: 0.11, blue: 0.09)], btn: Color(red: 0.93, green: 0.40, blue: 0.32),
                        led: Color(red: 0.3, green: 0.8, blue: 1), stick: Color(red: 0.32, green: 0.05, blue: 0.04))
        case .sky:
            return make([Color(red: 0.40, green: 0.66, blue: 0.93), Color(red: 0.20, green: 0.45, blue: 0.80)], btn: Color(red: 0.56, green: 0.78, blue: 0.97),
                        stick: Color(red: 0.08, green: 0.22, blue: 0.45))
        case .carbon:
            return make([Color(white: 0.20), Color(white: 0.04)], gloss: 0.5, ink: .white.opacity(0.6), btn: Color(white: 0.28), led: Color(red: 0.3, green: 0.6, blue: 1),
                        stick: Color(white: 0.12))
        case .pearl:
            return make([Color(white: 0.97), Color(white: 0.82)], gloss: 0.6, ink: Color(white: 0.35), btn: Color(white: 0.88), label: Color(white: 0.35),
                        led: Color(red: 0.3, green: 0.6, blue: 1), stick: Color(white: 0.55))
        case .neon:
            return .init(style: .neon, body: [Color(red: 0.03, green: 0.03, blue: 0.08), Color(red: 0.06, green: 0.02, blue: 0.12)], gloss: 0.1,
                         bezel: .black, brand: brand, ink: Neon.cyan.opacity(0.8), led: Neon.cyan, dpad: Color.white.opacity(0.12),
                         face: Neon.violet.opacity(0.45), label: .white, pill: Color.white.opacity(0.14), shoulder: Color.white.opacity(0.14),
                         stick: Color.white.opacity(0.10), cBtn: Neon.cyan.opacity(0.45))
        }
    }
}

// MARK: - Multitáctil real (varios dedos, deslizar entre botones, sin fallos de gestos)

struct TouchZone: Equatable { let pad: UInt32; let dpad: Bool; let rect: CGRect; var stick = false }
struct ZoneKey: PreferenceKey {
    static var defaultValue: [TouchZone] = []
    static func reduce(value: inout [TouchZone], nextValue: () -> [TouchZone]) { value += nextValue() }
}

final class TouchHub: ObservableObject {
    static let shared = TouchHub()
    @Published private(set) var mask: UInt32 = 0
    /// Posición del stick táctil (-1…1) para dibujarlo.
    @Published private(set) var stickPos: CGPoint = .zero
    var zones: [TouchZone] = []
    var enabled = true
    private let tap = UIImpactFeedbackGenerator(style: .medium)
    private let tick = UIImpactFeedbackGenerator(style: .rigid)

    func hit(_ p: CGPoint) -> Bool { enabled && zones.contains { $0.rect.insetBy(dx: $0.dpad || $0.stick ? -24 : -14, dy: $0.dpad || $0.stick ? -24 : -14).contains(p) } }
    private enum Owner { case dpad, stick, button }
    private var owner: [Int: Owner] = [:]   // dedo → control donde empezó
    func update(_ pts: [CGPoint]) { updateTouches(pts.enumerated().map { ($0.offset, $0.element) }) }
    func updateTouches(_ touches: [(Int, CGPoint)]) {
        var m: UInt32 = 0
        let pts = touches.map(\.1)
        owner = owner.filter { k, _ in touches.contains { $0.0 == k } }
        var sv = CGPoint.zero
        if enabled {
            let dirs = zones.first { $0.dpad }
            let stk = zones.first { $0.stick }
            for (id, p) in touches {
                // Cada dedo pertenece al control donde empezó: si partió en la cruceta, sigue siendo cruceta aunque se desplace.
                if owner[id] == nil {
                    let onButton = nearestButtons(p, margin: 4) != nil
                    let onPad = dirs.map { hypot(p.x - $0.rect.midX, p.y - $0.rect.midY) <= $0.rect.width / 2 + 26 } ?? false
                    let onStick = stk.map { hypot(p.x - $0.rect.midX, p.y - $0.rect.midY) <= $0.rect.width / 2 + 26 } ?? false
                    owner[id] = onButton ? .button : (onStick ? .stick : (onPad ? .dpad : .button))
                }
                if owner[id] == .stick, let k = stk {
                    let r = k.rect.width / 2
                    var v = CGPoint(x: (p.x - k.rect.midX) / r, y: (p.y - k.rect.midY) / r)
                    let len = hypot(v.x, v.y)
                    if len > 1 { v = CGPoint(x: v.x / len, y: v.y / len) }
                    if len < 0.08 { v = .zero }
                    sv = v
                } else if owner[id] == .dpad, let d = dirs {
                    let dx = p.x - d.rect.midX, dy = p.y - d.rect.midY
                    let dead = d.rect.width * 0.07
                    if abs(dx) > dead && abs(dx) > abs(dy) * 0.42 { m |= dx < 0 ? Pad.left.mask : Pad.right.mask }
                    if abs(dy) > dead && abs(dy) > abs(dx) * 0.42 { m |= dy < 0 ? Pad.up.mask : Pad.down.mask }
                } else if let b = nearestButtons(p, margin: 18) {
                    m |= b   // uno o dos botones (pulgar entre dos = ambos, como en un mando real)
                }
            }
        }
        let sp = enabled ? sv : .zero
        if sp != stickPos {
            stickPos = sp
            Engine.shared.stick = (Int16(max(-1, min(1, sp.x)) * 32767), Int16(max(-1, min(1, sp.y)) * 32767))
        }
        guard m != mask else { return }
        let fresh = m & ~mask
        if fresh != 0, ControlPrefs.shared.haptics {
            let dirs = Pad.up.mask | Pad.down.mask | Pad.left.mask | Pad.right.mask
            if fresh & ~dirs != 0 { tap.impactOccurred(intensity: 0.9) } else { tick.impactOccurred(intensity: 0.6) }
        }
        if !pts.isEmpty, ControlPrefs.shared.padConnected { ControlPrefs.shared.padConnected = false }
        mask = m
        Engine.shared.setSource("touch", mask: m)
        tap.prepare(); tick.prepare()
    }
    /// Botón más cercano; si el dedo queda entre dos botones vecinos, devuelve ambos (Y+B corriendo y saltando).
    private func nearestButtons(_ p: CGPoint, margin: CGFloat) -> UInt32? {
        let c = zones.filter { !$0.dpad && $0.rect.insetBy(dx: -margin, dy: -margin).contains(p) }
            .map { ($0, hypot($0.rect.midX - p.x, $0.rect.midY - p.y)) }.sorted { $0.1 < $1.1 }
        guard let first = c.first else { return nil }
        var m = first.0.pad
        if c.count > 1, c[1].1 < first.1 * 1.35, first.1 > first.0.rect.width * 0.28 { m |= c[1].0.pad }
        return m
    }
    /// Al salir de un juego: suelta todo pero NO borra las zonas (el siguiente juego ya pudo registrarlas)
    /// y deja los táctiles activos (si se salió con el menú abierto quedaban apagados).
    func reset() { owner = [:]; update([]); enabled = true }
    #if DEBUG
    /// Prueba: pulsa el centro de cada zona y anota la máscara resultante.
    func selfTest() -> String {
        var out = ""
        for z in zones {
            let c = CGPoint(x: z.rect.midX, y: z.rect.midY)
            if z.dpad {
                for (n, dx, dy) in [("up", 0.0, -0.35), ("down", 0, 0.35), ("left", -0.35, 0), ("right", 0.35, 0)] {
                    update([CGPoint(x: c.x + dx * z.rect.width, y: c.y + dy * z.rect.height)]); out += "dpad-\(n)=\(mask) "
                }
            } else { update([c]); out += "btn\(z.pad)=\(mask) " }
            update([])
        }
        if let d = zones.first(where: { $0.dpad }), let a = zones.first(where: { $0.pad == Pad.a.mask }) {
            update([CGPoint(x: d.rect.midX, y: d.rect.midY - d.rect.height * 0.35), CGPoint(x: a.rect.midX, y: a.rect.midY)]); out += "multi(up+A)=\(mask) "; update([])
            if let y = zones.first(where: { $0.pad == Pad.y.mask }), let b = zones.first(where: { $0.pad == Pad.b.mask }) {
                update([CGPoint(x: (y.rect.midX + b.rect.midX) / 2, y: (y.rect.midY + b.rect.midY) / 2)]); out += "roll(Y+B)=\(mask) "; update([])
            }
        }
        return "zones=\(zones.count) " + out
    }
    #endif
}

final class TouchSurface: UIView {
    private var active = Set<UITouch>()
    override init(frame: CGRect) { super.init(frame: frame); isMultipleTouchEnabled = true; isExclusiveTouch = false; backgroundColor = .clear }
    required init?(coder: NSCoder) { fatalError() }
    override func hitTest(_ p: CGPoint, with e: UIEvent?) -> UIView? { TouchHub.shared.hit(p) ? self : nil }
    // Cada dedo se sigue por separado: varios botones a la vez y deslizar entre ellos.
    private func sync() { TouchHub.shared.updateTouches(active.map { (ObjectIdentifier($0).hashValue, $0.location(in: self)) }) }
    override func touchesBegan(_ t: Set<UITouch>, with e: UIEvent?) { active.formUnion(t); sync() }
    override func touchesMoved(_ t: Set<UITouch>, with e: UIEvent?) { sync() }
    override func touchesEnded(_ t: Set<UITouch>, with e: UIEvent?) { active.subtract(t); sync() }
    override func touchesCancelled(_ t: Set<UITouch>, with e: UIEvent?) { active.subtract(t); sync() }
    override func didMoveToWindow() { super.didMoveToWindow(); window?.isMultipleTouchEnabled = true; superview?.isMultipleTouchEnabled = true }
}

struct TouchSurfaceView: UIViewRepresentable {
    func makeUIView(context: Context) -> TouchSurface { TouchSurface() }
    func updateUIView(_ v: TouchSurface, context: Context) {}
}

extension View {
    func zone(_ pad: UInt32, dpad: Bool = false, stick: Bool = false) -> some View {
        background(GeometryReader { g in Color.clear.preference(key: ZoneKey.self, value: [TouchZone(pad: pad, dpad: dpad, rect: g.frame(in: .named("pad")), stick: stick)]) })
    }
}

// MARK: - Piezas

struct SkinDPad: View {
    let t: SkinTheme; let size: CGFloat; var ghost = false
    @ObservedObject private var hub = TouchHub.shared
    var body: some View {
        let arm = size * 0.34
        let col = ghost ? Color.white.opacity(0.22) : t.dpad
        ZStack {
            if !ghost && t.style != .neon {   // hueco en la carcasa
                Circle().fill(Color.black.opacity(0.12)).frame(width: size * 1.02).blur(radius: 1)
            }
            Group {
                RoundedRectangle(cornerRadius: size * 0.05).frame(width: arm, height: size)
                RoundedRectangle(cornerRadius: size * 0.05).frame(width: size, height: arm)
            }
            .foregroundStyle(col)
            .shadow(color: .black.opacity(ghost ? 0 : 0.45), radius: 2, y: 3)
            Circle().fill(Color.black.opacity(0.25)).frame(width: arm * 0.45)
            ForEach([(Pad.up, 0.0, -1.0, "arrowtriangle.up.fill"), (.down, 0, 1, "arrowtriangle.down.fill"),
                     (.left, -1, 0, "arrowtriangle.left.fill"), (.right, 1, 0, "arrowtriangle.right.fill")], id: \.0.rawValue) { p, dx, dy, s in
                Image(systemName: s).font(.system(size: size * 0.09))
                    .foregroundStyle(.white.opacity(hub.mask & p.mask != 0 ? 0.95 : 0.22))
                    .offset(x: dx * size * 0.36, y: dy * size * 0.36)
            }
        }
        .frame(width: size, height: size)
        .rotation3DEffect(.degrees(tilt.0), axis: (x: tilt.1, y: tilt.2, z: 0), perspective: 0.6)
        .zone(0, dpad: true)
    }
    private var tilt: (Double, CGFloat, CGFloat) {
        let m = hub.mask
        if m & Pad.up.mask != 0 { return (10, 1, 0) }
        if m & Pad.down.mask != 0 { return (-10, 1, 0) }
        if m & Pad.left.mask != 0 { return (-10, 0, 1) }
        if m & Pad.right.mask != 0 { return (10, 0, 1) }
        return (0, 0, 0)
    }
}

struct SkinButton: View {
    let label: String; let def: Pad; let color: Color; let t: SkinTheme; let size: CGFloat
    var ghost = false; var labelBelow = false
    @ObservedObject private var hub = TouchHub.shared
    @ObservedObject private var prefs = ControlPrefs.shared
    var body: some View {
        let pad = prefs.touchPad(label, default: def)
        let down = hub.mask & pad.mask != 0
        VStack(spacing: 4) {
            ZStack {
                Circle().fill(ghost ? Color.white.opacity(0.2) : color)
                    .overlay(Circle().fill(LinearGradient(colors: [.white.opacity(down ? 0 : 0.28), .clear, .black.opacity(0.25)], startPoint: .topLeading, endPoint: .bottomTrailing)))
                    .overlay(Circle().stroke(Color.black.opacity(ghost ? 0 : 0.35), lineWidth: 1.5))
                    .shadow(color: .black.opacity(ghost || down ? 0 : 0.45), radius: 2, y: down ? 0 : 3)
                if !labelBelow { Text(label).font(.system(size: size * 0.36, weight: .heavy, design: .rounded)).foregroundStyle(t.label) }
            }
            .frame(width: size, height: size)
            .scaleEffect(down ? 0.9 : 1).offset(y: down ? 2 : 0)
            .animation(.easeOut(duration: 0.06), value: down)
            .zone(pad.mask)
            if labelBelow { Text(label).font(.system(size: 13, weight: .heavy, design: .rounded)).foregroundStyle(t.ink) }
        }
    }
}

struct SkinPill: View {
    let label: String; let def: Pad; let t: SkinTheme; var ghost = false; var w: CGFloat = 54
    @ObservedObject private var hub = TouchHub.shared
    @ObservedObject private var prefs = ControlPrefs.shared
    var body: some View {
        let pad = prefs.touchPad(label, default: def)
        let down = hub.mask & pad.mask != 0
        VStack(spacing: 14) {
            Capsule().fill(ghost ? Color.white.opacity(0.2) : t.pill).frame(width: w, height: w * 0.28)
                .overlay(Capsule().stroke(.black.opacity(ghost ? 0 : 0.3), lineWidth: 1))
                .rotationEffect(.degrees(t.style == .neon || ghost ? 0 : -25))
                .scaleEffect(down ? 0.9 : 1)
                .zone(pad.mask)
            Text(label).font(.system(size: 10, weight: .heavy, design: .rounded)).tracking(1).foregroundStyle(ghost ? .white.opacity(0.7) : t.ink)
        }
    }
}

struct SkinShoulder: View {
    let label: String; let def: Pad; let t: SkinTheme; var ghost = false; var w: CGFloat = 96; var left = true
    @ObservedObject private var hub = TouchHub.shared
    @ObservedObject private var prefs = ControlPrefs.shared
    var body: some View {
        let pad = prefs.touchPad(label, default: def)
        let down = hub.mask & pad.mask != 0
        UnevenRoundedRectangle(topLeadingRadius: left ? 22 : 8, bottomLeadingRadius: 6, bottomTrailingRadius: 6, topTrailingRadius: left ? 8 : 22)
            .fill(ghost ? Color.white.opacity(0.2) : t.shoulder)
            .overlay(Text(label).font(.system(size: 16, weight: .heavy, design: .rounded)).foregroundStyle(ghost ? .white : t.ink))
            .overlay(UnevenRoundedRectangle(topLeadingRadius: left ? 22 : 8, bottomLeadingRadius: 6, bottomTrailingRadius: 6, topTrailingRadius: left ? 8 : 22).stroke(.black.opacity(ghost ? 0 : 0.3), lineWidth: 1))
            .frame(width: w, height: 38)
            .scaleEffect(down ? 0.94 : 1)
            .zone(pad.mask)
    }
}

// MARK: - Piezas propias de ARIAemu 3D

/// Stick analógico táctil (izquierdo).
struct SkinStick: View {
    let t: SkinTheme; let size: CGFloat; var ghost = false
    @ObservedObject private var hub = TouchHub.shared
    var body: some View {
        let knob = size * 0.52
        ZStack {
            Circle().fill(ghost ? Color.white.opacity(0.10) : Color.black.opacity(0.22))
                .overlay(Circle().stroke(Color.white.opacity(ghost ? 0.25 : 0.12), lineWidth: 1.5))
            Circle().fill(ghost ? Color.white.opacity(0.28) : t.stick)
                .overlay(Circle().fill(LinearGradient(colors: [.white.opacity(0.30), .clear, .black.opacity(0.35)], startPoint: .topLeading, endPoint: .bottomTrailing)))
                .overlay(Circle().stroke(Color.black.opacity(ghost ? 0 : 0.4), lineWidth: 1.5))
                .overlay(Circle().stroke(Color.white.opacity(0.10), lineWidth: 1).padding(knob * 0.18))
                .frame(width: knob, height: knob)
                .shadow(color: .black.opacity(ghost ? 0 : 0.45), radius: 3, y: 3)
                .offset(x: hub.stickPos.x * (size - knob) / 2, y: hub.stickPos.y * (size - knob) / 2)
        }
        .frame(width: size, height: size)
        .zone(0, stick: true)
    }
}

/// Botón con símbolo (△ ○ ✕ □) o letra.
struct SymButton: View {
    let key: String; let symbol: String?; let text: String?; let def: Pad; let color: Color; let mark: Color; let t: SkinTheme; let size: CGFloat
    var ghost = false
    @ObservedObject private var hub = TouchHub.shared
    @ObservedObject private var prefs = ControlPrefs.shared
    var body: some View {
        let pad = prefs.touchPad(key, default: def)
        let down = hub.mask & pad.mask != 0
        ZStack {
            Circle().fill(ghost ? Color.white.opacity(0.2) : color)
                .overlay(Circle().fill(LinearGradient(colors: [.white.opacity(down ? 0 : 0.30), .clear, .black.opacity(0.25)], startPoint: .topLeading, endPoint: .bottomTrailing)))
                .overlay(Circle().stroke(Color.black.opacity(ghost ? 0 : 0.35), lineWidth: 1.5))
                .shadow(color: .black.opacity(ghost || down ? 0 : 0.45), radius: 2, y: down ? 0 : 3)
            if let symbol { Image(systemName: symbol).font(.system(size: size * 0.38, weight: .heavy)).foregroundStyle(ghost ? .white : mark) }
            if let text { Text(text).font(.system(size: size * 0.40, weight: .heavy, design: .rounded)).foregroundStyle(ghost ? .white : mark) }
        }
        .frame(width: size, height: size)
        .scaleEffect(down ? 0.9 : 1).offset(y: down ? 2 : 0)
        .animation(.easeOut(duration: 0.06), value: down)
        .zone(pad.mask)
    }
}

/// Botones de acción: rombo de cuatro (estilo portátil). En la consola 64: A y B grandes.
struct FaceCluster: View {
    let t: SkinTheme; let console: Console; let s: CGFloat; var ghost = false
    var body: some View {
        if console == .psp {
            let tri = Color(red: 0.25, green: 0.78, blue: 0.62), cir = Color(red: 0.93, green: 0.30, blue: 0.36)
            let crs = Color(red: 0.42, green: 0.62, blue: 0.95), sqr = Color(red: 0.86, green: 0.48, blue: 0.80)
            let neutral = t.style == .neon
            ZStack {
                if !ghost { Circle().fill(Color.black.opacity(0.10)).frame(width: s * 2.8) }
                SymButton(key: "△", symbol: "triangle", text: nil, def: .x, color: t.face, mark: neutral ? .white : tri, t: t, size: s, ghost: ghost).offset(y: -s * 0.82)
                SymButton(key: "✕", symbol: "xmark", text: nil, def: .b, color: t.face, mark: neutral ? .white : crs, t: t, size: s, ghost: ghost).offset(y: s * 0.82)
                SymButton(key: "□", symbol: "square", text: nil, def: .y, color: t.face, mark: neutral ? .white : sqr, t: t, size: s, ghost: ghost).offset(x: -s * 0.82)
                SymButton(key: "○", symbol: "circle", text: nil, def: .a, color: t.face, mark: neutral ? .white : cir, t: t, size: s, ghost: ghost).offset(x: s * 0.82)
            }.frame(width: s * 2.75, height: s * 2.75)
        } else {
            ZStack {
                if !ghost { Capsule().fill(Color.black.opacity(0.10)).frame(width: s * 2.7, height: s * 1.45).rotationEffect(.degrees(-30)) }
                SymButton(key: "B", symbol: nil, text: "B", def: .y, color: t.face, mark: t.label, t: t, size: s * 1.0, ghost: ghost).offset(x: -s * 0.62, y: -s * 0.36)
                SymButton(key: "A", symbol: nil, text: "A", def: .b, color: t.face, mark: t.label, t: t, size: s * 1.18, ghost: ghost).offset(x: s * 0.50, y: s * 0.34)
            }.frame(width: s * 2.75, height: s * 2.2)
        }
    }
}

/// Botones C (consola 64): cuatro botones chicos con flecha.
struct CCluster: View {
    let t: SkinTheme; let s: CGFloat; var ghost = false
    var body: some View {
        let c = s * 0.62
        ZStack {
            SymButton(key: "C▲", symbol: "chevron.up", text: nil, def: .cUp, color: t.cBtn, mark: .black.opacity(0.6), t: t, size: c, ghost: ghost).offset(y: -c * 0.95)
            SymButton(key: "C▼", symbol: "chevron.down", text: nil, def: .cDown, color: t.cBtn, mark: .black.opacity(0.6), t: t, size: c, ghost: ghost).offset(y: c * 0.95)
            SymButton(key: "C◀", symbol: "chevron.left", text: nil, def: .cLeft, color: t.cBtn, mark: .black.opacity(0.6), t: t, size: c, ghost: ghost).offset(x: -c * 0.95)
            SymButton(key: "C▶", symbol: "chevron.right", text: nil, def: .cRight, color: t.cBtn, mark: .black.opacity(0.6), t: t, size: c, ghost: ghost).offset(x: c * 0.95)
            Text("C").font(.system(size: c * 0.45, weight: .heavy, design: .rounded)).foregroundStyle(ghost ? .white.opacity(0.6) : t.ink)
        }.frame(width: c * 2.95, height: c * 2.95)
    }
}

/// Gatillo Z (consola 64).
struct ZTrigger: View {
    let t: SkinTheme; var ghost = false; var w: CGFloat = 64
    @ObservedObject private var hub = TouchHub.shared
    @ObservedObject private var prefs = ControlPrefs.shared
    var body: some View {
        let pad = prefs.touchPad("Z", default: .l2)
        let down = hub.mask & pad.mask != 0
        RoundedRectangle(cornerRadius: 12, style: .continuous)
            .fill(ghost ? Color.white.opacity(0.2) : t.shoulder)
            .overlay(Text("Z").font(.system(size: 17, weight: .heavy, design: .rounded)).foregroundStyle(ghost ? .white : t.label))
            .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(.black.opacity(ghost ? 0 : 0.3), lineWidth: 1))
            .frame(width: w, height: 40)
            .scaleEffect(down ? 0.92 : 1)
            .zone(pad.mask)
    }
}

// MARK: - Distribuciones

struct SkinLayout<Screen: View, Menu: View>: View {
    let console: Console
    let screen: Screen
    let menu: Menu
    @ObservedObject private var prefs = ControlPrefs.shared
    @AppStorage("cp.skin") private var skinRaw = SkinID.auto.rawValue
    @AppStorage("cp.landFull") private var landFull = false

    private var skin: SkinID { SkinID(rawValue: skinRaw) ?? .auto }
    private var aspect: CGFloat { console == .psp ? 480.0 / 272.0 : 4.0 / 3.0 }

    var body: some View {
        if CommandLine.arguments.contains("-landpreview") {
            GeometryReader { g in content.frame(width: g.size.height, height: g.size.width).rotationEffect(.degrees(90)).position(x: g.size.width / 2, y: g.size.height / 2) }
        } else { content }
    }

    private var content: some View {
        GeometryReader { geo in
            let t = SkinTheme.of(skin, console: console)
            let landscape = geo.size.width > geo.size.height
            ZStack {
                if landscape { landscapeView(geo, t, ghost: landFull) } else { portrait(geo, t) }
                TouchSurfaceView().allowsHitTesting(!prefs.touchHidden)
            }
            .coordinateSpace(name: "pad")
            .onPreferenceChange(ZoneKey.self) { z in TouchHub.shared.zones = prefs.touchHidden ? [] : z }
        }
        .ignoresSafeArea(.container, edges: .horizontal)
        .onAppear { TouchHub.shared.reset() }
        .onDisappear { TouchHub.shared.reset() }
    }

    private func shell(_ t: SkinTheme) -> some View {
        ZStack {
            LinearGradient(colors: t.body, startPoint: .topLeading, endPoint: .bottomTrailing)
            LinearGradient(colors: [.white.opacity(t.gloss * 0.55), .clear, .clear, .black.opacity(0.18)], startPoint: .top, endPoint: .bottom)
            if t.style == .neon { GamerBackground().opacity(0.6) }
        }.ignoresSafeArea()
    }

    private func bezel<V: View>(_ t: SkinTheme, _ inner: V) -> some View {
        inner
            .padding(.horizontal, 10).padding(.vertical, 8)
            .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(LinearGradient(colors: [Color(white: 0.10), Color(white: 0.01)], startPoint: .topLeading, endPoint: .bottomTrailing)))
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.white.opacity(0.12), lineWidth: 1))
            .shadow(color: .black.opacity(0.35), radius: 5, y: 3)
    }

    private func startSelect(_ t: SkinTheme, ghost: Bool) -> some View {
        HStack(spacing: 18) {
            if console == .psp { SkinPill(label: "SELECT", def: .select, t: t, ghost: ghost, w: 46) }
            SkinPill(label: "START", def: .start, t: t, ghost: ghost, w: 46)
        }
    }

    // Vertical: pantalla arriba, mandos abajo
    private func portrait(_ geo: GeometryProxy, _ t: SkinTheme) -> some View {
        let w = geo.size.width
        let d = min(w * 0.36, 160) * prefs.scale
        let s = min(w * 0.145, 64) * prefs.scale
        let st = min(w * 0.30, 128) * prefs.scale
        return ZStack {
            shell(t)
            VStack(spacing: 0) {
                bezel(t, VStack(spacing: 6) {
                    HStack(spacing: 6) {
                        Circle().fill(t.led).frame(width: 7, height: 7).shadow(color: t.led, radius: 4)
                        Text(t.brand).font(.system(size: 12, weight: .heavy, design: .rounded)).italic().foregroundStyle(.white.opacity(0.55))
                        Spacer(); menu
                    }
                    screen.frame(maxWidth: .infinity)
                })
                .padding(.horizontal, 12).padding(.top, 6)
                Spacer(minLength: 8)
                Group {
                    HStack(alignment: .top) {
                        VStack(alignment: .leading, spacing: 10) {
                            SkinShoulder(label: "L", def: .l, t: t, w: 92)
                            if console == .n64 { ZTrigger(t: t, w: 70) }
                        }
                        Spacer()
                        SkinShoulder(label: "R", def: .r, t: t, w: 92, left: false)
                    }.padding(.horizontal, 14).padding(.bottom, 8)
                    HStack(alignment: .center) {
                        SkinDPad(t: t, size: d).padding(.leading, 16)
                        Spacer()
                        FaceCluster(t: t, console: console, s: s).padding(.trailing, 14)
                    }
                    HStack(alignment: .center) {
                        SkinStick(t: t, size: st).padding(.leading, 26)
                        Spacer()
                        if console == .n64 { CCluster(t: t, s: s).padding(.trailing, 26) } else { startSelect(t, ghost: false).padding(.trailing, 22) }
                    }.padding(.top, 6)
                    if console == .n64 { startSelect(t, ghost: false).padding(.top, 4) }
                }
                .opacity(prefs.touchHidden ? 0 : 1)
                Spacer(minLength: 10)
            }
        }
    }

    // Horizontal estilo portátil: pantalla al centro, cruceta y stick a la izquierda, botones a la derecha.
    // ghost = pantalla completa con mandos translúcidos.
    private func landscapeView(_ geo: GeometryProxy, _ t: SkinTheme, ghost: Bool) -> some View {
        let h = geo.size.height, w = geo.size.width
        let sh = ghost ? h : min(h - 36, h * 0.84)
        let sw = min(sh * aspect, ghost ? w : w * 0.66)
        let sh2 = sw / aspect
        let side = max((w - sw) / 2 - 10, 120)
        let d = max(96, min(h * 0.33, 132, side - 18)) * prefs.scale
        let st = max(84, min(h * 0.27, 112, side - 30)) * prefs.scale
        let s = max(36, min(h * 0.12, 52, (side - 16) / 2.8)) * prefs.scale
        return ZStack {
            if ghost { Color.black.ignoresSafeArea() } else { shell(t) }
            if ghost {
                screen.frame(width: sw, height: sh2)
            } else {
                bezel(t, VStack(spacing: 3) {
                    screen.frame(width: sw, height: sh2)
                    Text(t.brand).font(.system(size: 11, weight: .heavy, design: .rounded)).italic().foregroundStyle(.white.opacity(0.5))
                })
            }
            HStack(alignment: .top, spacing: 0) {
                VStack(spacing: 10) {
                    HStack(spacing: 8) {
                        SkinShoulder(label: "L", def: .l, t: t, ghost: ghost, w: 76)
                        if console == .n64 { ZTrigger(t: t, ghost: ghost, w: 50) }
                    }
                    Spacer(minLength: 0)
                    SkinDPad(t: t, size: d, ghost: ghost)
                    Spacer(minLength: 0)
                    SkinStick(t: t, size: st, ghost: ghost)
                }.frame(width: side)
                Spacer(minLength: 0)
                VStack(spacing: 10) {
                    SkinShoulder(label: "R", def: .r, t: t, ghost: ghost, w: 76, left: false)
                    Spacer(minLength: 0)
                    FaceCluster(t: t, console: console, s: s, ghost: ghost)
                    Spacer(minLength: 0)
                    if console == .n64 { CCluster(t: t, s: s, ghost: ghost) }
                    startSelect(t, ghost: ghost)
                }.frame(width: side)
            }
            .padding(.horizontal, 8).padding(.top, 8).padding(.bottom, 14)
            .opacity(prefs.touchHidden ? 0 : 1)
            VStack { HStack { Spacer(); menu.opacity(0.85) }; Spacer() }.padding(.top, 6).padding(.trailing, side + 14)
        }
    }
}

/// Vista previa pequeña para elegir skin en Opciones.
struct SkinChip: View {
    let id: SkinID; let selected: Bool
    var body: some View {
        let t = SkinTheme.of(id == .auto ? .lime : id, console: .psp)
        VStack(spacing: 6) {
            ZStack {
                RoundedRectangle(cornerRadius: 16).fill(LinearGradient(colors: t.body, startPoint: .topLeading, endPoint: .bottomTrailing))
                HStack(spacing: 5) {
                    Image(systemName: "plus").font(.system(size: 11, weight: .black)).foregroundStyle(t.dpad)
                    RoundedRectangle(cornerRadius: 3).fill(Color(white: 0.05)).frame(width: 34, height: 22)
                        .overlay(Image(systemName: "wand.and.stars").font(.system(size: 11)).foregroundStyle(.white).opacity(id == .auto ? 1 : 0))
                    VStack(spacing: 2) { Circle().fill(t.face).frame(width: 6); HStack(spacing: 2) { Circle().fill(t.face).frame(width: 6); Circle().fill(t.face).frame(width: 6) } }
                }
            }
            .frame(width: 74, height: 44)
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(selected ? Neon.cyan : .white.opacity(0.15), lineWidth: selected ? 3 : 1))
            Text(id.title).font(.system(size: 10, weight: .semibold)).multilineTextAlignment(.center).frame(width: 80).lineLimit(2)
        }
    }
}
