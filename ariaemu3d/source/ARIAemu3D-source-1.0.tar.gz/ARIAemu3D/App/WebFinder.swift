import SwiftUI
import WebKit
import WatchConnectivity

/// Páginas guardadas por el usuario (se comparten con el reloj).
final class PageStore: ObservableObject {
    static let shared = PageStore()
    @Published private(set) var pages: [String] = UserDefaults.standard.stringArray(forKey: "np_pages") ?? []
    func add(_ s: String) { guard !s.isEmpty, !pages.contains(s) else { return }; pages.insert(s, at: 0); save() }
    func remove(_ s: String) { pages.removeAll { $0 == s }; save() }
    func save() {
        UserDefaults.standard.set(pages, forKey: "np_pages")
        if WCSession.isSupported(), WCSession.default.activationState == .activated { try? WCSession.default.updateApplicationContext(["pages": pages]) }
    }
}

struct Found: Identifiable, Hashable { var id: String { url.absoluteString }; let url: URL
    var name: String { url.lastPathComponent.removingPercentEncoding ?? url.lastPathComponent } }

@MainActor
final class Finder: NSObject, ObservableObject, WKNavigationDelegate, WKDownloadDelegate {
    static let exts: Set<String> = ["gb", "gbc", "gba", "sfc", "smc", "md", "gen", "bin", "smd", "zip", "7z"]
    let web: WKWebView
    @Published var url: URL?
    @Published var found: [Found] = []
    @Published var loading = false
    @Published var toast = ""
    @Published var downloading: Set<String> = []
    var autoList = false, onList: (() -> Void)?
    var lib: PhoneLibrary?
    private var dests: [ObjectIdentifier: URL] = [:]

    override init() {
        web = WKWebView(frame: .zero, configuration: WKWebViewConfiguration())
        super.init()
        web.navigationDelegate = self
        web.allowsBackForwardNavigationGestures = true
    }
    func go(_ text: String) {
        let s = text.trimmingCharacters(in: .whitespacesAndNewlines); guard !s.isEmpty else { return }
        let looksURL = !s.contains(" ") && s.contains(".")
        let u = looksURL ? URL(string: s.hasPrefix("http") ? s : "https://" + s)
                         : URL(string: "https://www.google.com/search?q=" + (s.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? s))
        if let u { web.load(URLRequest(url: u)) }
    }
    func scan() {
        web.evaluateJavaScript("Array.from(document.querySelectorAll('a[href]')).map(a=>a.href)") { [weak self] r, _ in
            guard let self, let hrefs = r as? [String] else { return }
            var seen = Set<String>()
            self.found = hrefs.compactMap(URL.init(string:)).filter {
                Self.exts.contains($0.pathExtension.lowercased()) && seen.insert($0.lastPathComponent.lowercased()).inserted
            }.map(Found.init).sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
            if self.autoList, !self.found.isEmpty { self.autoList = false; self.onList?() }
        }
    }
    func fetch(_ f: Found) {
        downloading.insert(f.id)
        Task {
            defer { downloading.remove(f.id) }
            do {
                var req = URLRequest(url: f.url); req.timeoutInterval = 120
                let (tmp, resp) = try await URLSession.shared.download(for: req)
                if let h = resp as? HTTPURLResponse, h.statusCode >= 400 { toast = "El servidor respondió \(h.statusCode)"; return }
                if (resp.mimeType ?? "").contains("html") { toast = "Ese enlace abre una página, no un juego"; return }
                let dst = FileManager.default.temporaryDirectory.appendingPathComponent(resp.suggestedFilename ?? f.name)
                try? FileManager.default.removeItem(at: dst); try FileManager.default.moveItem(at: tmp, to: dst)
                finish(dst)
            } catch { toast = "Error: \(error.localizedDescription)" }
        }
    }
    private func finish(_ file: URL) {
        let send = lib?.importFiles([file]) ?? [file]
        _ = send   // el reloj se sincroniza solo
        toast = lib?.lastImport ?? "Descargado"
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }

    // MARK: navegación — un toque sobre un archivo de juego lo descarga directo
    func webView(_ w: WKWebView, decidePolicyFor a: WKNavigationAction) async -> WKNavigationActionPolicy {
        if let u = a.request.url, Self.exts.contains(u.pathExtension.lowercased()) { return .download }
        return a.shouldPerformDownload ? .download : .allow
    }
    func webView(_ w: WKWebView, decidePolicyFor r: WKNavigationResponse) async -> WKNavigationResponsePolicy {
        let cd = (r.response as? HTTPURLResponse)?.value(forHTTPHeaderField: "Content-Disposition")?.lowercased() ?? ""
        return (!r.canShowMIMEType || cd.contains("attachment")) ? .download : .allow
    }
    func webView(_ w: WKWebView, navigationAction: WKNavigationAction, didBecome d: WKDownload) { d.delegate = self; toast = "Descargando…" }
    func webView(_ w: WKWebView, navigationResponse: WKNavigationResponse, didBecome d: WKDownload) { d.delegate = self; toast = "Descargando…" }
    func download(_ d: WKDownload, decideDestinationUsing r: URLResponse, suggestedFilename n: String) async -> URL? {
        let dst = FileManager.default.temporaryDirectory.appendingPathComponent(n)
        try? FileManager.default.removeItem(at: dst); dests[ObjectIdentifier(d)] = dst; return dst
    }
    func downloadDidFinish(_ d: WKDownload) { if let u = dests.removeValue(forKey: ObjectIdentifier(d)) { finish(u) } }
    func download(_ d: WKDownload, didFailWithError e: Error, resumeData: Data?) { toast = "Falló la descarga" }
    func webView(_ w: WKWebView, didStartProvisionalNavigation n: WKNavigation!) { loading = true; found = [] }
    func webView(_ w: WKWebView, didFinish n: WKNavigation!) { loading = false; url = w.url; scan() }
    func webView(_ w: WKWebView, didFail n: WKNavigation!, withError e: Error) { loading = false }
}

private struct WebBox: UIViewRepresentable {
    let web: WKWebView
    func makeUIView(context: Context) -> WKWebView { web }
    func updateUIView(_ v: WKWebView, context: Context) {}
}

/// Buscar juegos: Google dentro de la app → abrir página → tocar un juego (o "Juegos aquí") → queda en la biblioteca y en el reloj.
struct WebFinderView: View {
    @ObservedObject var lib: PhoneLibrary
    @Environment(\.dismiss) private var dismiss
    @StateObject private var f = Finder()
    @ObservedObject private var store = PageStore.shared
    @State private var query = ""
    @State private var showList = false
    @State private var showPages = false
    @FocusState private var focused: Bool
    var start: String? = nil

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass").foregroundStyle(Neon.cyan)
                    TextField("Busca en Google o pega un enlace", text: $query)
                        .textInputAutocapitalization(.never).autocorrectionDisabled().submitLabel(.search)
                        .focused($focused).onSubmit { f.go(query); focused = false }
                    if f.loading { ProgressView().scaleEffect(0.8) }
                    // Copia el enlace en el Mac o en Safari y pégalo aquí (Portapapeles universal / Handoff)
                    PasteButton(payloadType: String.self) { s in
                        guard let t = s.first else { return }
                        Task { @MainActor in query = t; f.go(t); focused = false }
                    }.labelStyle(.iconOnly).buttonBorderShape(.capsule).tint(Neon.cyan)
                }
                .padding(12).background(Neon.panel, in: RoundedRectangle(cornerRadius: 14))
                .padding(.horizontal, 12).padding(.vertical, 8)
                ZStack {
                    WebBox(web: f.web)
                    if f.url == nil && !f.loading { hint }
                }
                bar
            }
            .background(Color.black.ignoresSafeArea())
            .navigationTitle("Buscar juegos").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Cerrar") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) { Button { showPages = true } label: { Image(systemName: "star.square.on.square") } }
            }
            .overlay(alignment: .top) {
                if !f.toast.isEmpty {
                    Text(f.toast).font(.footnote.bold()).padding(.horizontal, 14).padding(.vertical, 8)
                        .background(Neon.panel.opacity(0.95), in: Capsule()).padding(.top, 64)
                        .task(id: f.toast) { try? await Task.sleep(for: .seconds(2.5)); f.toast = "" }
                }
            }
            .sheet(isPresented: $showList) { list.presentationDetents([.medium, .large]) }
            .sheet(isPresented: $showPages) { pages.presentationDetents([.medium, .large]) }
            .sheet(item: Binding(get: { lib.choice }, set: { _ in })) { c in
                VersionPicker(choice: c) { lib.save($0); f.toast = lib.lastImport }.preferredColorScheme(.dark).tint(Neon.cyan)
            }
        }
        .onAppear {
            f.lib = lib; f.onList = { showList = true }
            if let start { f.autoList = true; f.go(start) } else { focused = true }
        }
    }

    private var hint: some View {
        VStack(spacing: 14) {
            Image(systemName: "gamecontroller.fill").font(.system(size: 44)).foregroundStyle(Neon.cyan)
            Text("1. Busca la página de tus juegos\n2. Toca ★ para guardarla\n3. Toca un juego y aparece solo en tu biblioteca y en el reloj")
                .multilineTextAlignment(.center).font(.callout).foregroundStyle(.white.opacity(0.8))
            Text("Descarga solo juegos que te pertenezcan o de dominio público.").font(.caption2).foregroundStyle(.secondary)
        }.padding(30).frame(maxWidth: .infinity, maxHeight: .infinity).background(Color.black)
    }

    private var bar: some View {
        HStack(spacing: 18) {
            Button { f.web.goBack() } label: { Image(systemName: "chevron.left") }.disabled(!f.web.canGoBack)
            Button { f.web.goForward() } label: { Image(systemName: "chevron.right") }.disabled(!f.web.canGoForward)
            Spacer()
            Button { showList = true } label: {
                Label(f.found.isEmpty ? "Sin juegos aquí" : "\(f.found.count) juegos aquí", systemImage: "square.grid.2x2.fill")
                    .font(.subheadline.bold()).padding(.horizontal, 14).padding(.vertical, 9)
                    .background(f.found.isEmpty ? Neon.panel : Neon.cyan.opacity(0.9), in: Capsule())
                    .foregroundStyle(f.found.isEmpty ? .white.opacity(0.5) : .black)
            }.disabled(f.found.isEmpty)
            Spacer()
            let cur = f.url?.absoluteString ?? ""
            let saved = store.pages.contains(cur)
            Button { if saved { store.remove(cur) } else { store.add(cur); f.toast = "★ Página guardada (también en el reloj)" } } label: {
                Image(systemName: saved ? "star.fill" : "star")
            }.disabled(cur.isEmpty || cur.contains("google."))
        }
        .font(.title3.weight(.semibold)).tint(Neon.cyan)
        .padding(.horizontal, 20).padding(.vertical, 10).background(Neon.panel.opacity(0.9))
    }

    private var list: some View {
        NavigationStack {
            List(f.found) { g in
                Button { f.fetch(g) } label: {
                    HStack {
                        Text(g.name).lineLimit(2).foregroundStyle(.white)
                        Spacer()
                        if f.downloading.contains(g.id) { ProgressView() } else { Image(systemName: "arrow.down.circle.fill").foregroundStyle(Neon.cyan) }
                    }
                }.disabled(f.downloading.contains(g.id))
            }
            .navigationTitle("\(f.found.count) juegos").navigationBarTitleDisplayMode(.inline)
        }.preferredColorScheme(.dark)
    }

    private var pages: some View {
        NavigationStack {
            List {
                if store.pages.isEmpty { Text("Aún no guardas páginas. Abre una y toca ★.").foregroundStyle(.secondary) }
                ForEach(store.pages, id: \.self) { p in
                    Button { showPages = false; f.autoList = true; f.go(p) } label: { Text(p).font(.footnote).lineLimit(2) }
                        .swipeActions { Button(role: .destructive) { store.remove(p) } label: { Label("Quitar", systemImage: "trash") } }
                }
            }
            .navigationTitle("Mis páginas").navigationBarTitleDisplayMode(.inline)
        }.preferredColorScheme(.dark)
    }
}
