import SwiftUI
import GameController
import UIKit

// MARK: - Mandos Bluetooth (MFi / DualSense / Xbox / Switch Pro)

final class PadInput {
    static let shared = PadInput()
    private var started = false
    var learn: ((PadKey) -> Void)?
    var onLive: ((UInt32) -> Void)?
    var nav: ((UInt32) -> Void)?
    static func refresh() { if GCController.controllers().isEmpty { ControlPrefs.shared.padConnected = false } }
    func start() {
        guard !started else { return }; started = true
        let nc = NotificationCenter.default
        nc.addObserver(forName: .GCControllerDidConnect, object: nil, queue: .main) { [weak self] n in
            if let c = n.object as? GCController { self?.bind(c) }
            Self.refresh()
        }
        nc.addObserver(forName: .GCControllerDidDisconnect, object: nil, queue: .main) { _ in
            DispatchQueue.main.async {
                Self.refresh()
                if !ControlPrefs.shared.padConnected { Engine.shared.setSource("gc", mask: 0) }
            }
        }
        GCController.controllers().forEach(bind)
        GCController.startWirelessControllerDiscovery {}
    }
    private func bind(_ c: GCController) {
        guard let g = c.extendedGamepad else { return }
        let cid = ControlPrefs.id(c)
        g.valueChangedHandler = { [weak self] g, _ in
            if let l = self?.learn {
                if let k = PadKey.allCases.first(where: { ![.up, .down, .left, .right].contains($0) && $0.pressed(g) }) { self?.learn = nil; l(k) }
                return
            }
            let map = ControlPrefs.shared.map(forID: cid)
            var m: UInt32 = 0
            for k in PadKey.allCases where k.pressed(g) { if let r = map[k.rawValue], r >= 0 { m |= UInt32(1) << UInt32(r) } }
            if m != 0, !ControlPrefs.shared.padConnected { ControlPrefs.shared.padConnected = true }
            self?.onLive?(m); self?.nav?(m)
            Engine.shared.setSource("gc", mask: m)
        }
    }
}

// MARK: - Controles táctiles

private struct TouchButton: View {
    let label: String
    let pad: Pad
    @ObservedObject private var prefs = ControlPrefs.shared
    private var eff: Pad { prefs.touchPad(label, default: pad) }
    var size: CGFloat = 64
    var round = true
    var tint: Color = Color(white: 0.58).opacity(0.75)
    @State private var down = false
    var body: some View {
        Text(label)
            .font(.system(size: size * (round ? 0.38 : 0.26), weight: .heavy, design: .rounded))
            .foregroundStyle(.white)
            .frame(width: round ? size : size * 1.5, height: round ? size : size * 0.62)
            .background((down ? tint.opacity(0.6) : tint), in: round ? AnyShape(Circle()) : AnyShape(Capsule()))
            .overlay((round ? AnyShape(Circle()) : AnyShape(Capsule())).stroke(.white.opacity(0.45), lineWidth: 1.2))
            .scaleEffect(down ? 0.93 : 1)
            .opacity(prefs.touchHidden ? 0 : prefs.opacity)
            .allowsHitTesting(!prefs.touchHidden)
            .contentShape(Rectangle())
            .gesture(DragGesture(minimumDistance: 0)
                .onChanged { _ in
                    if !down { down = true; if prefs.haptics { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
                        Engine.shared.setSource("t\(label)", mask: eff.mask) }
                }
                .onEnded { _ in down = false; Engine.shared.setSource("t\(label)", mask: 0) })
    }
}

private struct DPad: View {
    var size: CGFloat = 170
    @ObservedObject private var prefs = ControlPrefs.shared
    @State private var mask: UInt32 = 0
    var body: some View {
        ZStack {
            Circle().fill(Color(white: 0.58).opacity(0.5)).overlay(Circle().stroke(.white.opacity(0.28), lineWidth: 1.2))
            arrow("chevron.up", 0, -1, .up); arrow("chevron.down", 0, 1, .down)
            arrow("chevron.left", -1, 0, .left); arrow("chevron.right", 1, 0, .right)
        }
        .frame(width: size, height: size)
        .opacity(prefs.touchHidden ? 0 : prefs.opacity)
        .allowsHitTesting(!prefs.touchHidden)
        .contentShape(Circle())
        .gesture(DragGesture(minimumDistance: 0).onChanged { v in update(v.location) }.onEnded { _ in set(0) })
    }
    private func arrow(_ s: String, _ dx: CGFloat, _ dy: CGFloat, _ p: Pad) -> some View {
        Image(systemName: s).font(.system(size: size * 0.16, weight: .black))
            .foregroundStyle(mask & p.mask != 0 ? Color.white : Color.white.opacity(0.4))
            .offset(x: dx * size * 0.30, y: dy * size * 0.30)
    }
    private func update(_ pt: CGPoint) {
        let c = CGPoint(x: size / 2, y: size / 2)
        let dx = pt.x - c.x, dy = pt.y - c.y
        var m: UInt32 = 0
        let dead = size * 0.12
        if abs(dx) > dead && abs(dx) > abs(dy) * 0.45 { m |= dx < 0 ? Pad.left.mask : Pad.right.mask }
        if abs(dy) > dead && abs(dy) > abs(dx) * 0.45 { m |= dy < 0 ? Pad.up.mask : Pad.down.mask }
        set(m)
    }
    private func set(_ m: UInt32) {
        if m != mask {
            if m != 0 && prefs.haptics { UIImpactFeedbackGenerator(style: .rigid).impactOccurred(intensity: 0.5) }
            mask = m; Engine.shared.setSource("tdpad", mask: m)
        }
    }
}

// MARK: - Pantalla de juego

struct PhoneGameView: View {
    let game: LibGame
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var engine = Engine.shared
    @State private var failed: String?
    @State private var menu = false
    @State private var showControls = false
    @ObservedObject private var prefs = ControlPrefs.shared
    @State private var console: Console = .n64
    @State private var toast: String?
    @State private var stateRev = 0
    private let netOn = false
    private static let rel: RelativeDateTimeFormatter = { let f = RelativeDateTimeFormatter(); f.unitsStyle = .short; f.locale = Locale(identifier: "es"); return f }()

    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.ignoresSafeArea()
                SkinLayout(console: console, screen: screen, menu: menuButton)
                if menu { pauseOverlay.transition(.opacity) }
                if let t = toast {
                    VStack { Text(t).font(.footnote.weight(.semibold)).foregroundStyle(.white).padding(.horizontal, 16).padding(.vertical, 9)
                        .background(.black.opacity(0.75), in: Capsule()).overlay(Capsule().stroke(.white.opacity(0.25), lineWidth: 1)); Spacer() }
                        .padding(.top, 14).transition(.move(edge: .top).combined(with: .opacity)).allowsHitTesting(false)
                }
                if let f = failed {
                    VStack(spacing: 12) { Text(f).multilineTextAlignment(.center); Button("Volver") { dismiss() }.buttonStyle(.borderedProminent) }
                        .padding(24).background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18)).padding()
                }
            }
        }
        .sheet(isPresented: $showControls, onDismiss: { engine.setPaused(false) }) { ControlSettingsView().preferredColorScheme(.dark).tint(Neon.cyan) }
        .onChange(of: menu) { _, m in TouchHub.shared.enabled = !m; if m { TouchHub.shared.update([]) } }
        .onChange(of: showControls) { _, m in TouchHub.shared.enabled = !m; if m { TouchHub.shared.update([]) } }
        .statusBarHidden(true)
        .persistentSystemOverlays(.hidden)
        .onAppear {
            PadInput.shared.start()
            guard let c = Console.from(ext: game.ext) else { failed = "Formato no compatible"; return }
            console = c
            // Capturas para la App Store: imagen original (sin ROM) en vez del juego.
            if let i = CommandLine.arguments.firstIndex(of: "-fakeframe"), i + 1 < CommandLine.arguments.count,
               let ui = UIImage(contentsOfFile: Library.docs.appendingPathComponent(CommandLine.arguments[i + 1]).path) ?? UIImage(contentsOfFile: CommandLine.arguments[i + 1]), let cg = ui.cgImage {
                if let j = CommandLine.arguments.firstIndex(of: "-fakeconsole"), j + 1 < CommandLine.arguments.count,
                   let fc = Console.from(ext: CommandLine.arguments[j + 1]) { console = fc } else { console = .psp }
                if CommandLine.arguments.contains("-forceland"), let sc = UIApplication.shared.connectedScenes.first as? UIWindowScene {
                    sc.requestGeometryUpdate(.iOS(interfaceOrientations: .landscapeRight)) { _ in }
                }
                for t in [0.3, 1.0, 2.0] { DispatchQueue.main.asyncAfter(deadline: .now() + t) { engine.frame = cg } }
                return
            }
            // Retoma justo donde quedaste (estado automático); "Reiniciar" parte de cero.
            let resumed = FileManager.default.fileExists(atPath: ROM(url: game.url, console: c).stateURL(0).path)
            let ok = engine.start(ROM(url: game.url, console: c), resume: true)
            if !ok { failed = engine.status } else {
                PhoneLibrary.markPlayed(game.id); UserDefaults.standard.set(game.id, forKey: "lastPlayedID")
                if resumed { flash("Continuando donde quedaste") }
                #if DEBUG
                let args = CommandLine.arguments
                if args.contains("-forceland"), let sc = UIApplication.shared.connectedScenes.first as? UIWindowScene {
                    sc.requestGeometryUpdate(.iOS(interfaceOrientations: .landscapeRight)) { _ in }
                }
                if args.contains("-touchtest") {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                        try? TouchHub.shared.selfTest().write(to: Library.docs.appendingPathComponent("touch.txt"), atomically: true, encoding: .utf8)
                    }
                }
                if args.contains("-teststate") {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                        engine.saveState(1) { ok in engine.loadState(1) { ok2 in flash("TEST save=\(ok) load=\(ok2)") } }
                    }
                }
                if args.contains("-menu") { DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) { openMenu() } }
                #endif
            }
        }
        .onDisappear { engine.stop() }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.willResignActiveNotification)) { _ in
            engine.setPaused(true); engine.saveState(0)   // por si el sistema cierra la app
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
            if !menu && !showControls { engine.setPaused(false) }
        }
    }

    // MARK: Menú de pausa

    private func openMenu() { if !netOn { engine.setPaused(true) }; stateRev += 1; withAnimation(.easeOut(duration: 0.18)) { menu = true } }
    private func closeMenu() { withAnimation(.easeOut(duration: 0.18)) { menu = false }; engine.setPaused(false) }
    private func flash(_ t: String) {
        withAnimation(.spring(response: 0.3)) { toast = t }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) { if toast == t { withAnimation { toast = nil } } }
    }
    private func exitGame() {
        if let f = engine.frame, !engine.suppressSaves { PhoneLibrary.saveSnapshot(f, id: game.id) }
        engine.stop(); dismiss()
    }

    private var pauseOverlay: some View {
        ZStack {
            Color.black.opacity(0.62).ignoresSafeArea().onTapGesture { closeMenu() }
            ViewThatFits(in: .vertical) {
                pauseCard
                ScrollView { pauseCard }
            }
            .frame(maxWidth: 400)
            .background(Neon.panel.opacity(0.97), in: RoundedRectangle(cornerRadius: 28, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).stroke(LinearGradient(colors: [Neon.cyan.opacity(0.7), Neon.magenta.opacity(0.5)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1.2))
            .shadow(color: .black.opacity(0.5), radius: 30, y: 12)
            .padding(18)
        }
        .environment(\.colorScheme, .dark)
    }

    private var pauseCard: some View {
        VStack(spacing: 14) {
            VStack(spacing: 2) {
                Text(game.cleanTitle).font(.system(size: 20, weight: .bold, design: .rounded)).foregroundStyle(.white).lineLimit(2).multilineTextAlignment(.center)
                Text(netOn ? "" : "\(console.title) · En pausa").font(.caption.weight(.semibold)).foregroundStyle(.white.opacity(0.55))
            }
            Button { closeMenu() } label: {
                Label("Continuar", systemImage: "play.fill").font(.system(size: 17, weight: .heavy, design: .rounded)).foregroundStyle(.white)
                    .frame(maxWidth: .infinity).frame(height: 48)
                    .background(Neon.hero, in: Capsule()).shadow(color: Neon.magenta.opacity(0.6), radius: 12)
            }.buttonStyle(.plain)
            // 1. Partidas guardadas
            if !netOn {
                menuSection("Partidas guardadas") {
                    VStack(spacing: 0) {
                        ForEach(1...3, id: \.self) { slot in
                            slotRow(slot)
                            if slot < 3 { Divider().overlay(.white.opacity(0.08)) }
                        }
                    }
                }
            }
            // 3. Ajustes de la partida
            menuSection("Ajustes") {
                VStack(spacing: 0) {
                    HStack {
                        Label("Velocidad", systemImage: "forward.fill").font(.subheadline.weight(.semibold)).foregroundStyle(.white.opacity(0.9))
                        Spacer()
                        Picker("", selection: $engine.turbo) { Text("x1").tag(1); Text("x2").tag(2); Text("x3").tag(3) }
                            .pickerStyle(.segmented).frame(width: 150).disabled(netOn)
                    }.padding(.horizontal, 14).padding(.vertical, 10)
                    Divider().overlay(.white.opacity(0.08))
                    menuRow("Controles y skins", "gamecontroller.fill", "Botones, mando, apariencia") { menu = false; showControls = true }
                }
            }
            // 4. Acciones finales
            HStack(spacing: 10) {
                if !netOn { pill("Reiniciar", "arrow.counterclockwise") { engine.reset(); closeMenu() } }
                pill("Salir", "rectangle.portrait.and.arrow.right", danger: true) { exitGame() }
            }
        }
        .padding(20)
    }

    private func slotRow(_ slot: Int) -> some View {
        let _ = stateRev
        let date = engine.stateDate(slot)
        return HStack(spacing: 8) {
            VStack(alignment: .leading, spacing: 1) {
                Text("Estado \(slot)").font(.subheadline.weight(.semibold)).foregroundStyle(.white)
                Text(date.map { Self.rel.localizedString(for: $0, relativeTo: Date()) } ?? "Vacío").font(.caption2).foregroundStyle(.white.opacity(0.5))
            }
            Spacer()
            Button("Guardar") {
                engine.saveState(slot) { ok in
                    stateRev += 1
                    if ok { closeMenu(); flash("Estado \(slot) guardado") } else { flash("No se pudo guardar el estado") }
                }
            }.buttonStyle(.bordered).tint(.white).controlSize(.small)
            Button("Cargar") {
                engine.loadState(slot) { ok in
                    if ok { closeMenu(); flash("Estado \(slot) cargado") } else { flash("No se pudo cargar el estado") }
                }
            }.buttonStyle(.borderedProminent).tint(Neon.violet).controlSize(.small).disabled(date == nil)
        }
        .padding(.horizontal, 14).padding(.vertical, 9)
    }

    private func menuSection<C: View>(_ title: String, @ViewBuilder _ content: () -> C) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title.uppercased()).font(.system(size: 11, weight: .heavy, design: .rounded)).tracking(1).foregroundStyle(.white.opacity(0.45)).padding(.leading, 6)
            content().background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
    }
    private func menuRow(_ t: String, _ icon: String, _ sub: String, _ a: @escaping () -> Void) -> some View {
        Button(action: a) {
            HStack(spacing: 12) {
                Image(systemName: icon).font(.system(size: 15, weight: .bold)).foregroundStyle(.white).frame(width: 32, height: 32)
                    .background(Neon.violet.opacity(0.55), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
                VStack(alignment: .leading, spacing: 1) {
                    Text(t).font(.subheadline.weight(.semibold)).foregroundStyle(.white)
                    Text(sub).font(.caption2).foregroundStyle(.white.opacity(0.5))
                }
                Spacer()
                Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.white.opacity(0.35))
            }
            .padding(.horizontal, 14).padding(.vertical, 9).contentShape(Rectangle())
        }.buttonStyle(.plain)
    }

    private func pill(_ t: String, _ icon: String, danger: Bool = false, _ a: @escaping () -> Void) -> some View {
        Button(action: a) {
            VStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 17, weight: .bold))
                Text(t).font(.caption2.weight(.semibold))
            }
            .foregroundStyle(danger ? Color(red: 1, green: 0.42, blue: 0.45) : .white)
            .frame(maxWidth: .infinity).frame(height: 56)
            .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }.buttonStyle(.plain)
    }

    // Caja de tamaño fijo según la consola: así el layout no "respira" si el núcleo cambia la resolución del frame
    private var nominalAspect: CGFloat {
        switch console { case .psp: return 480.0 / 272.0; case .n64: return 4.0 / 3.0 }
    }
    private var screen: some View {
        Color.black.aspectRatio(nominalAspect, contentMode: .fit)
            .overlay(
                ZStack {
                    if let f = engine.frame {   // vista previa (capturas y -fakeframe)
                        Image(decorative: f, scale: 1).resizable().aspectRatio(contentMode: .fit)
                    } else {
                        GLScreen()
                    }
                }
            )
            .clipShape(RoundedRectangle(cornerRadius: 4))
    }

    private var menuButton: some View {
        Button { openMenu() } label: { Image(systemName: "ellipsis").font(.system(size: 18, weight: .bold)).foregroundStyle(.white).frame(width: 38, height: 38).background(.white.opacity(0.16), in: Circle()) }
    }

    private func actionButtons(_ s: CGFloat) -> some View {
        let r1 = Color(red: 0.88, green: 0.14, blue: 0.2).opacity(0.85)
        let r2 = Color(red: 0.7, green: 0.1, blue: 0.16).opacity(0.85)
        return Group {
            if console.hasXY {
                ZStack {
                    TouchButton(label: "X", pad: .x, size: s, tint: r2).offset(y: -s * 0.76)
                    TouchButton(label: "B", pad: .b, size: s, tint: r1).offset(y: s * 0.76)
                    TouchButton(label: "Y", pad: .y, size: s, tint: r2).offset(x: -s * 0.76)
                    TouchButton(label: "A", pad: .a, size: s, tint: r1).offset(x: s * 0.76)
                }.frame(width: s * 2.6, height: s * 2.6)
            } else {
                HStack(spacing: s * 0.25) {
                    TouchButton(label: "B", pad: .b, size: s * 1.1, tint: r2).offset(y: s * 0.3)
                    TouchButton(label: "A", pad: .a, size: s * 1.1, tint: r1).offset(y: -s * 0.1)
                }
            }
        }
    }

    private var startSelect: some View {
        HStack(spacing: 14) { TouchButton(label: "SELECT", pad: .select, size: 52, round: false); TouchButton(label: "START", pad: .start, size: 52, round: false) }
    }

    private func portraitLayout(_ geo: GeometryProxy) -> some View {
        VStack(spacing: 0) {
            HStack {
                if console.hasShoulders { TouchButton(label: "L", pad: .l, size: 54, round: false) }
                Spacer(); menuButton; Spacer()
                if console.hasShoulders { TouchButton(label: "R", pad: .r, size: 54, round: false) }
            }.padding(.horizontal, 14).padding(.top, 2)
            screen.frame(maxWidth: .infinity)
            Spacer(minLength: 8)
            HStack(alignment: .center) {
                DPad(size: min(190, geo.size.width * 0.44) * prefs.scale).padding(.leading, 12)
                Spacer()
                actionButtons(min(70, geo.size.width * 0.17) * prefs.scale).padding(.trailing, 12)
            }
            startSelect.padding(.top, 6).padding(.bottom, 10)
        }
    }

    private func landscapeLayout(_ geo: GeometryProxy) -> some View {
        ZStack {
            screen.frame(maxWidth: .infinity, maxHeight: .infinity)
            HStack(alignment: .bottom) {
                VStack(alignment: .leading, spacing: 10) {
                    if console.hasShoulders { TouchButton(label: "L", pad: .l, size: 50, round: false) }
                    Spacer(minLength: 0)
                    DPad(size: min(190, geo.size.height * 0.5) * prefs.scale)
                    TouchButton(label: "SELECT", pad: .select, size: 44, round: false)
                }
                Spacer(minLength: 0)
                VStack(alignment: .trailing, spacing: 10) {
                    if console.hasShoulders { TouchButton(label: "R", pad: .r, size: 50, round: false) }
                    Spacer(minLength: 0)
                    actionButtons(min(64, geo.size.height * 0.16) * prefs.scale)
                    TouchButton(label: "START", pad: .start, size: 44, round: false)
                }
            }.padding(.horizontal, 16).padding(.vertical, 8)
            VStack { HStack { Spacer(); menuButton.opacity(0.55) }; Spacer() }.padding(8)
        }
    }
}
