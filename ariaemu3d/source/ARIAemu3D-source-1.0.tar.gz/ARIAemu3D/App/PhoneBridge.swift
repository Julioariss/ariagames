import Foundation
// Compatibilidad: Engine.swift (compartido con el reloj) usa `Library`.
enum Library {
    static let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    static let savesDir = docs.appendingPathComponent("Saves", isDirectory: true)
}
