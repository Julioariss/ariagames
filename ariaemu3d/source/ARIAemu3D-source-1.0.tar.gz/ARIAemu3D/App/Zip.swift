import Foundation
import Compression

/// Lector mínimo de ZIP (métodos 0 y 8) usando el directorio central.
enum Zip {
    struct Result { var files: [(String, Data)] = []; var encrypted = false; var zip64 = false }
    static func extract(_ d: Data) -> Result {
        var out = Result()
        let b = [UInt8](d)
        func u16(_ o: Int) -> Int { Int(b[o]) | Int(b[o + 1]) << 8 }
        func u32(_ o: Int) -> Int { u16(o) | u16(o + 2) << 16 }
        guard b.count > 22 else { return out }
        var e = b.count - 22
        while e >= 0, u32(e) != 0x06054b50 { e -= 1 }
        guard e >= 0 else { return out }
        var p = u32(e + 16)
        let count = u16(e + 10)
        if (Int64(truncatingIfNeeded: p) & 0xFFFFFFFF) == 0xFFFFFFFF || count == 0xFFFF { out.zip64 = true; return out }
        for _ in 0..<count {
            guard p + 46 <= b.count, u32(p) == 0x02014b50 else { break }
            let flags = u16(p + 8), method = u16(p + 10), csize = u32(p + 20), usize = u32(p + 24)
            let nl = u16(p + 28), el = u16(p + 30), cl = u16(p + 32), lo = u32(p + 42)
            let name = String(decoding: b[(p + 46)..<(p + 46 + nl)], as: UTF8.self)
            p += 46 + nl + el + cl
            if flags & 1 != 0 { out.encrypted = true; continue }
            if name.hasSuffix("/") { continue }
            guard lo + 30 <= b.count, u32(lo) == 0x04034b50 else { continue }
            let start = lo + 30 + u16(lo + 26) + u16(lo + 28)
            guard start + csize <= b.count else { continue }
            if method == 0 {
                out.files.append((name, Data(b[start..<(start + csize)])))
            } else if method == 8, usize > 0 {
                var dst = [UInt8](repeating: 0, count: usize)
                let n = b[start..<(start + csize)].withUnsafeBufferPointer { src in
                    dst.withUnsafeMutableBufferPointer { compression_decode_buffer($0.baseAddress!, usize, src.baseAddress!, csize, nil, COMPRESSION_ZLIB) }
                }
                if n == usize { out.files.append((name, Data(dst))) }
            } else {
                out.files.append((name + " (método \(method) no soportado)", Data()))
            }
        }
        return out
    }
}


/// Extrae ROMs de un ZIP/7z/ROM suelto (detectado por contenido). Compartido iPhone/reloj.
enum Archive {
    /// Prioridad de región: USA > Mundial > Europa > otras > Japón; penaliza beta/demo/hack.
    static func score(_ name: String) -> Int {
        let t = name.lowercased(); var s = 50
        if t.contains("(usa") || t.contains("(u)") { s = 100 } else if t.contains("(world") { s = 90 }
        else if t.contains("(europe") || t.contains("(e)") { s = 60 } else if t.contains("(japan") || t.contains("(j)") { s = 20 }
        for bad in ["beta", "proto", "demo", "sample", "unl", "pirate", "hack", "[b", "[h"] where t.contains(bad) { s -= 60 }
        if t.contains("(rev") { s += 3 }
        return s
    }
    /// En el reloj no hay selector cómodo: de un comprimido con varias versiones se guarda solo la mejor.
    static func best(_ files: [(String, Data)]) -> [(String, Data)] {
        let roms = files.filter { Console.romExts.contains((($0.0 as NSString).pathExtension).lowercased()) && $0.1.count > 0x150 }
        guard roms.count > 1, let top = roms.max(by: { score($0.0) < score($1.0) }) else { return roms }
        return [top]
    }

    static func roms(from data: Data, name: String) -> (files: [(String, Data)], error: String?) {
        guard data.count > 4 else { return ([], "archivo vacío") }
        let head = [UInt8](data.prefix(6))
        let isZip = head[0] == 0x50 && head[1] == 0x4B && (head[2] == 3 || head[2] == 5 || head[2] == 7)
        let is7z = head.count == 6 && head == [0x37, 0x7A, 0xBC, 0xAF, 0x27, 0x1C]
        var out: [(String, Data)] = []
        if isZip {
            let r = Zip.extract(data)
            if r.encrypted { return ([], "ZIP con contraseña") }
            if r.zip64 { return ([], "ZIP64 (demasiado grande)") }
            out = r.files
        } else if is7z {
            final class Box { var items: [(String, Data)] = [] }
            let box = Box()
            let ok = data.withUnsafeBytes { raw -> Int32 in
                sz7_extract(raw.baseAddress, data.count, { n, b, l, ctx in
                    Unmanaged<Box>.fromOpaque(ctx!).takeUnretainedValue().items.append((String(cString: n!), Data(bytes: b!, count: l)))
                }, Unmanaged.passUnretained(box).toOpaque())
            }
            if ok != 0 { return ([], "7z dañado o no soportado") }
            out = box.items
        } else { out = [(name, data)] }
        let roms = out.map { ((($0.0 as NSString).lastPathComponent), $0.1) }
            .filter { Console.romExts.contains(($0.0 as NSString).pathExtension.lowercased()) && $0.1.count > 0x150 }
        return (roms, roms.isEmpty ? "sin juegos compatibles dentro" : nil)
    }
}
