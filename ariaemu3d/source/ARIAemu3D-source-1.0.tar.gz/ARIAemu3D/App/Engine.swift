import Foundation
import AVFoundation
import CoreGraphics
import SwiftUI
#if os(watchOS)
import WatchKit
#endif

enum Console: String, CaseIterable, Codable {
    case n64, psp
    var title: String { switch self { case .n64: "ARIA 64"; case .psp: "ARIA Pocket" } }
    var short: String { switch self { case .n64: "64"; case .psp: "POCKET" } }
    var kind: EmuCoreKind { switch self { case .n64: EMU_CORE_N64; case .psp: EMU_CORE_PSP } }
    var hasShoulders: Bool { true }
    var hasXY: Bool { true }
    var exts: Set<String> { switch self { case .n64: ["z64", "n64", "v64"]; case .psp: ["iso", "cso", "pbp", "chd"] } }
    static func from(ext: String) -> Console? {
        let e = ext.lowercased()
        return allCases.first { $0.exts.contains(e) }
    }
    static let romExts: Set<String> = Set(allCases.flatMap { $0.exts })
}

/// Bits del joypad libretro.
enum Pad: UInt32 {
    case b = 0, y, select, start, up, down, left, right, a, x, l, r, l2, r2, l3, r3
    /// Botones C de la consola 64: no van al núcleo como botones, se envían como stick derecho.
    case cUp = 16, cDown, cLeft, cRight
    var mask: UInt32 { 1 << rawValue }
    static let cMask: UInt32 = Pad.cUp.mask | Pad.cDown.mask | Pad.cLeft.mask | Pad.cRight.mask
}

enum WheelMode: Int, CaseIterable {
    case leftRight, upDown, shoulders
    var title: String { switch self { case .leftRight: "◀ ▶"; case .upDown: "▲ ▼"; case .shoulders: "L R" } }
    var long: String { switch self { case .leftRight: "Rueda: izquierda/derecha"; case .upDown: "Rueda: arriba/abajo"; case .shoulders: "Rueda: L / R" } }
}

struct ROM: Identifiable, Hashable {
    var id: String { url.lastPathComponent }
    let url: URL
    let console: Console
    var title: String { url.deletingPathExtension().lastPathComponent }
    var saveURL: URL { Library.savesDir.appendingPathComponent(id + ".sav") }
    /// Estado guardado: ranura 0 = automático (continuar donde quedaste), 1…3 = manuales.
    func stateURL(_ slot: Int) -> URL { Library.savesDir.appendingPathComponent(id + (slot == 0 ? ".auto" : ".s\(slot)") + ".state") }
}

/// Enlace de multijugador en lockstep (lo implementa la app del iPhone/iPad).
protocol NetLink: AnyObject {
    /// true mientras se sincroniza el estado inicial: la emulación espera.
    var hold: Bool { get }
    /// true durante una partida conectada.
    var active: Bool { get }
    /// Entrega (jugador 1, jugador 2) para el cuadro `frame`, o nil si aún falta la entrada remota.
    func exchange(frame: Int, local: UInt32) -> (UInt32, UInt32)?
    /// Llamado tras cada cuadro emulado en multijugador (para verificar sincronía).
    func frameDone(_ frame: Int)
}

final class Engine: ObservableObject {
    static let shared = Engine()
    @Published var frame: CGImage?
    @Published var running = false
    @Published var status = "Cargando…"
    @Published var wheelMode: WheelMode = .leftRight
    @Published var locked: Set<Int> = []   // botones fijos (raw de Pad)
    @Published var turbo: Int = 1 { didSet { turboFast = turbo } }          // x1…x5; se reinicia al abrir cada juego
    private var turboFast = 1
    @Published var fullscreen: Bool = UserDefaults.standard.bool(forKey: "fullscreen") {
        didSet { UserDefaults.standard.set(fullscreen, forKey: "fullscreen") }
    }
    var remember: Bool {
        get { rom.map { UserDefaults.standard.bool(forKey: "remember.\($0.id)") } ?? false }
        set { if let r = rom { UserDefaults.standard.set(newValue, forKey: "remember.\(r.id)"); persistLocks() } }
    }
    func lock(_ p: Pad) { locked.insert(Int(p.rawValue)); setSource("lock\(p.rawValue)", mask: p.mask); persistLocks() }
    func unlock(_ p: Pad) { locked.remove(Int(p.rawValue)); setSource("lock\(p.rawValue)", mask: 0); persistLocks() }
    func unlockAll() { for r in locked { setSource("lock\(r)", mask: 0) }; locked = []; persistLocks() }
    private func persistLocks() {
        guard let r = rom, remember else { return }
        UserDefaults.standard.set(Array(locked), forKey: "locks.\(r.id)")
    }
    private(set) var rom: ROM?
    private var thread: Thread?
    private let pauseSem = DispatchSemaphore(value: 0)
    @Published var paused = false
    private var frameSkip = 2
    private let lock = NSLock()
    private var sources: [String: UInt32] = [:]
    private var audio: AVAudioEngine?
    private var pending: [() -> Void] = []
    private let doneSem = DispatchSemaphore(value: 0)
    /// Guarda el estado automático al salir y lo retoma al volver a abrir el juego.
    var autoResume = false
    /// Multijugador: enlace activo, cuadro sincronizado y bloqueo de guardado (el invitado juega el estado del anfitrión).
    weak var net: NetLink?
    var netFrame = 0
    var suppressSaves = false
    /// Ejecuta en el hilo de emulación (entre cuadros).
    func onEmuThread(_ f: @escaping () -> Void) { perform(f) }
    /// Solo en el hilo de emulación.
    func stateData() -> Data? {
        let n = emu_state_size(); guard n > 0 else { return nil }
        var d = Data(count: n)
        return d.withUnsafeMutableBytes({ emu_state_save($0.baseAddress, n) }) ? d : nil
    }
    func loadStateData(_ d: Data) -> Bool { d.withUnsafeBytes { emu_state_load($0.baseAddress, d.count) } }
    var romHash = ""

    /// Ejecuta `f` en el hilo de emulación, entre cuadros (también si está en pausa).
    private func perform(_ f: @escaping () -> Void) {
        guard thread != nil else { return }
        lock.lock(); pending.append(f); lock.unlock()
        pauseSem.signal()
    }
    private func drain() {
        lock.lock(); let p = pending; pending.removeAll(); lock.unlock()
        for f in p { f() }
    }

    // MARK: Estados guardados
    private func writeState(_ url: URL) -> Bool {
        let n = emu_state_size()
        guard n > 0 else { return false }
        var buf = Data(count: n)
        let ok = buf.withUnsafeMutableBytes { emu_state_save($0.baseAddress, n) }
        guard ok else { return false }
        try? FileManager.default.createDirectory(at: Library.savesDir, withIntermediateDirectories: true)
        return (try? buf.write(to: url, options: .atomic)) != nil
    }
    private func readState(_ url: URL) -> Bool {
        guard let d = try? Data(contentsOf: url), !d.isEmpty else { return false }
        return d.withUnsafeBytes { emu_state_load($0.baseAddress, d.count) }
    }
    func hasState(_ slot: Int) -> Bool { rom.map { FileManager.default.fileExists(atPath: $0.stateURL(slot).path) } ?? false }
    func stateDate(_ slot: Int) -> Date? {
        guard let r = rom else { return nil }
        return (try? FileManager.default.attributesOfItem(atPath: r.stateURL(slot).path))?[.modificationDate] as? Date
    }
    func saveState(_ slot: Int, done: ((Bool) -> Void)? = nil) {
        guard let r = rom, thread != nil else { done?(false); return }
        perform { [weak self] in
            let ok = self?.writeState(r.stateURL(slot)) ?? false
            DispatchQueue.main.async { done?(ok) }
        }
    }
    func loadState(_ slot: Int, done: ((Bool) -> Void)? = nil) {
        guard let r = rom, thread != nil else { done?(false); return }
        perform { [weak self] in
            let ok = self?.readState(r.stateURL(slot)) ?? false
            DispatchQueue.main.async { done?(ok) }
        }
    }

    /// Stick analógico izquierdo (táctil o mando), -32767…32767.
    private var stickV: (Int16, Int16) = (0, 0)
    var stick: (Int16, Int16) { get { lock.lock(); defer { lock.unlock() }; return stickV } set { lock.lock(); stickV = newValue; lock.unlock() } }
    func setSource(_ name: String, mask: UInt32) {
        lock.lock(); sources[name] = mask; lock.unlock()
    }
    /// Prioridad: si hay un botón fijo y el usuario toca OTRO botón de acción, el tocado manda
    /// y los fijos de acción se suspenden mientras dure el toque; al soltar, el fijo vuelve.
    private var combined: UInt32 {
        lock.lock(); defer { lock.unlock() }
        let action = Pad.a.mask | Pad.b.mask | Pad.x.mask | Pad.y.mask | Pad.l.mask | Pad.r.mask
        var fixed: UInt32 = 0, live: UInt32 = 0, touched: UInt32 = 0
        for (k, v) in sources {
            if k.hasPrefix("lock") { fixed |= v } else { live |= v; if k.hasPrefix("t") { touched |= v & action } }
        }
        if touched != 0 { fixed &= ~action }
        return fixed | live
    }

    func pulse(_ pad: Pad, source: String, ms: Int = 90) {
        setSource(source, mask: pad.mask)
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(ms)) { [weak self] in self?.setSource(source, mask: 0) }
    }

    @discardableResult
    func start(_ rom: ROM, resume: Bool = false) -> Bool {
        stop()
        status = "Cargando…"
        let sys = Library.docs.appendingPathComponent("system", isDirectory: true)
        try? FileManager.default.createDirectory(at: sys, withIntermediateDirectories: true)
        emu_set_system_dir(sys.path)
        if rom.console == .psp { Engine.installPSPAssets(sys) }
        // Los núcleos 3D leen el archivo por su ruta (los ISO de PSP pesan GB): no se carga en memoria.
        let ok = emu_load(rom.console.kind, nil, 0, rom.url.path)
        guard ok else {
            status = "No pude abrir \"\(rom.url.lastPathComponent)\": " + String(cString: emu_error())
            return false
        }
        self.rom = rom
        romHash = rom.id
        suppressSaves = false; netFrame = 0
        wheelMode = WheelMode(rawValue: UserDefaults.standard.integer(forKey: "wheel.\(rom.console.rawValue)")) ?? .leftRight
        if let sav = try? Data(contentsOf: rom.saveURL) {
            var n = 0
            if let p = emu_sram(&n), n > 0 { sav.withUnsafeBytes { memcpy(p, $0.baseAddress, min(n, sav.count)) } }
        }
        autoResume = resume
        if resume { _ = readState(rom.stateURL(0)) }
        UserDefaults.standard.set(rom.id, forKey: "lastROM")
        locked = []
        if remember, let saved = UserDefaults.standard.array(forKey: "locks.\(rom.id)") as? [Int] {
            for r in saved { if let p = Pad(rawValue: UInt32(r)) { lock(p) } }
        }
        #if os(watchOS)
        frameSkip = (rom.console == .gb || rom.console == .gbc) ? 1 : 2
        #else
        frameSkip = 1   // iPhone/iPad: 60 cuadros por segundo reales
        #endif
        startAudio()
        running = true
        #if os(watchOS)
        WKExtension.shared().isFrontmostTimeoutExtended = true
        #endif
        turbo = 1; turboFast = 1
        let t = Thread { [weak self] in self?.loop() }
        t.qualityOfService = .userInteractive
        t.stackSize = 8 << 20
        t.name = "ARIAemu.loop"
        thread = t
        t.start()
        return true
    }

    /// Archivos de sistema del núcleo de PSP (fuentes, flash0, compatibilidad): se copian una vez desde la app.
    static func installPSPAssets(_ sys: URL) {
        let dst = sys.appendingPathComponent("PPSSPP", isDirectory: true), flag = dst.appendingPathComponent(".aria_v1")
        let fm = FileManager.default
        guard !fm.fileExists(atPath: flag.path), let src = Bundle.main.url(forResource: "PPSSPP", withExtension: nil) else { return }
        try? fm.removeItem(at: dst)
        try? fm.copyItem(at: src, to: dst)
        fm.createFile(atPath: flag.path, contents: nil)
    }

    static func fnv(_ d: Data) -> String {
        var h: UInt64 = 0xcbf29ce484222325
        d.withUnsafeBytes { for b in $0 { h = (h ^ UInt64(b)) &* 0x100000001b3 } }
        return String(h, radix: 16)
    }

    func setWheel(_ m: WheelMode) {
        wheelMode = m
        if let r = rom { UserDefaults.standard.set(m.rawValue, forKey: "wheel.\(r.console.rawValue)") }
    }

    private func loop() {
        let dt = 1.0 / emu_fps()
        var next = ProcessInfo.processInfo.systemUptime
        var n = 0
        var lastSave = ProcessInfo.processInfo.systemUptime
        defer { doneSem.signal() }
        let th = Thread.current
        while !th.isCancelled {
            drain()
            if paused {
                while paused && !th.isCancelled { pauseSem.wait(); drain() }
                next = ProcessInfo.processInfo.systemUptime
                if th.isCancelled { break }
            }
            var k = max(1, min(5, turboFast))
            if let link = net, link.hold || link.active {
                if link.hold { Thread.sleep(forTimeInterval: 0.005); next = ProcessInfo.processInfo.systemUptime; continue }
                guard let (p1, p2) = link.exchange(frame: netFrame, local: combined) else { continue }
                emu_set_buttons(p1); emu_set_buttons2(p2)
                k = 1
            } else {
                let m = combined
                emu_set_buttons(m & 0xFFFF); emu_set_buttons2(0)
                let cx: Int16 = m & Pad.cRight.mask != 0 ? 32767 : (m & Pad.cLeft.mask != 0 ? -32767 : 0)
                let cy: Int16 = m & Pad.cDown.mask != 0 ? 32767 : (m & Pad.cUp.mask != 0 ? -32767 : 0)
                emu_set_analog(1, cx, cy)
                let st = stick
                emu_set_analog(0, st.0, st.1)
            }
            n += 1
            for i in 0..<k {
                let show = (i == k - 1) && (n % frameSkip == 0)
                emu_set_video_enabled(show)
                emu_run_frame()
                if show { publishFrame() }
            }
            if let link = net, link.active { netFrame += 1; link.frameDone(netFrame - 1) }
            if ProcessInfo.processInfo.systemUptime - lastSave > 8 { saveSRAM(); lastSave = ProcessInfo.processInfo.systemUptime }
            next += dt
            let now = ProcessInfo.processInfo.systemUptime
            if next > now { Thread.sleep(forTimeInterval: next - now) } else if now - next > 0.2 { next = now }
        }
    }

    private func publishFrame() {
        var w: UInt32 = 0, h: UInt32 = 0
        guard let fb = emu_framebuffer(&w, &h), w > 0, h > 0 else { return }
        let len = Int(w * h) * 4
        let data = Data(bytes: fb, count: len)
        guard let prov = CGDataProvider(data: data as CFData) else { return }
        let img = CGImage(width: Int(w), height: Int(h), bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: Int(w) * 4,
                          space: CGColorSpaceCreateDeviceRGB(),
                          bitmapInfo: CGBitmapInfo(rawValue: CGBitmapInfo.byteOrder32Little.rawValue | CGImageAlphaInfo.noneSkipFirst.rawValue),
                          provider: prov, decode: nil, shouldInterpolate: false, intent: .defaultIntent)
        DispatchQueue.main.async { self.frame = img }
    }

    func saveSRAM() {
        guard let rom, !suppressSaves else { return }
        var n = 0
        guard let p = emu_sram(&n), n > 0 else { return }
        try? FileManager.default.createDirectory(at: Library.savesDir, withIntermediateDirectories: true)
        try? Data(bytes: p, count: n).write(to: rom.saveURL, options: .atomic)
    }

    func reset() { perform { emu_reset() } }

    /// Pausa al pasar a segundo plano; reanuda al volver (ahorra batería y no pierde partida).
    func setPaused(_ p: Bool) {
        guard running, p != paused else { return }
        paused = p
        if p { saveSRAM(); audio?.pause() } else { try? audio?.start(); pauseSem.signal() }
    }

    func stop() {
        guard thread != nil else { return }
        saveSRAM()
        thread?.cancel(); paused = false; pauseSem.signal(); thread = nil
        _ = doneSem.wait(timeout: .now() + 1.5)   // espera a que el hilo termine el cuadro en curso
        drain()
        if autoResume, !suppressSaves, let r = rom { _ = writeState(r.stateURL(0)) }
        saveSRAM()
        #if os(watchOS)
        WKExtension.shared().isFrontmostTimeoutExtended = false
        #endif
        for r in locked { setSource("lock\(r)", mask: 0) }
        locked = []
        audio?.stop(); audio = nil
        emu_unload()
        running = false; frame = nil
    }

    private func startAudio() {
        let rate = emu_sample_rate()
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .default)
        #if os(watchOS)
        session.activate(options: []) { [weak self] ok, _ in
            guard let self, ok else { return }
            self.buildAudio(rate)
        }
        #else
        try? session.setActive(true)
        buildAudio(rate)
        #endif
    }

    private func buildAudio(_ rate: Double) {
        do {
            DispatchQueue.main.async {
                let eng = AVAudioEngine()
                let fmt = AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: rate, channels: 2, interleaved: false)!
                var tmp = [Int16](repeating: 0, count: 8192 * 2)
                let node = AVAudioSourceNode(format: fmt) { _, _, frames, abl in
                    let bufs = UnsafeMutableAudioBufferListPointer(abl)
                    let want = min(Int(frames), 8192)
                    let got = tmp.withUnsafeMutableBufferPointer { emu_audio_pop($0.baseAddress, want) }
                    for c in 0..<min(2, bufs.count) {
                        let out = bufs[c].mData!.assumingMemoryBound(to: Float.self)
                        for i in 0..<Int(frames) { out[i] = i < got ? Float(tmp[i * 2 + c]) / 32768 : 0 }
                    }
                    return noErr
                }
                eng.attach(node)
                eng.connect(node, to: eng.mainMixerNode, format: fmt)
                try? eng.start()
                self.audio = eng
            }
        }
    }
}
