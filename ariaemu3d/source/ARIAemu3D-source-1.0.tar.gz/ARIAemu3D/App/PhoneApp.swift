import SwiftUI
import UniformTypeIdentifiers

/// App iPhone: sube ROMs (archivo suelto, ZIP o 7z) al Apple Watch. ARIAemu corre solo en el reloj.
@main
struct ARIAemuPhoneApp: App {
    @AppStorage("legalOK_phone_v1") private var legalOK = false
    var body: some Scene {
        WindowGroup {
            Launcher()
                .fullScreenCover(isPresented: Binding(get: { !legalOK }, set: { _ in })) {
                    LegalGateView { legalOK = true }.interactiveDismissDisabled()
                }
        }
    }
}

