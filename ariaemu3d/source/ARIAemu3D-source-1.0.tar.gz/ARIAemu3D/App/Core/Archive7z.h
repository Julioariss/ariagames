#ifndef ARCHIVE7Z_H
#define ARCHIVE7Z_H
#include <stddef.h>
#include <stdint.h>
/// Recorre un archivo .7z en memoria y llama cb(nombre, bytes, tamaño, ctx) por cada archivo (no carpetas).
/// Devuelve 0 si pudo abrirlo, <0 si no es 7z válido / sin soporte.
int sz7_extract(const void *data, size_t size, void (*cb)(const char *name, const uint8_t *bytes, size_t len, void *ctx), void *ctx);
#endif
