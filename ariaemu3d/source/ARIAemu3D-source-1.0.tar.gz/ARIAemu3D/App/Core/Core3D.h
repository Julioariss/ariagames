#ifndef CORE3D_H
#define CORE3D_H
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
typedef enum { C3D_N64 = 0, C3D_PSP = 1 } C3DKind;
void c3d_set_dirs(const char *system, const char *saves);
/* layer: CAEAGLLayer* (puntero opaco) donde se presenta la imagen */
void c3d_set_layer(void *layer);
bool c3d_load(C3DKind kind, const char *dylibPath, const char *romPath);
void c3d_unload(void);
void c3d_reset(void);
void c3d_run_frame(bool present);
void c3d_set_buttons(uint32_t mask);                 /* bits = RETRO_DEVICE_ID_JOYPAD_* */
void c3d_set_analog(int idx, int16_t x, int16_t y);  /* idx 0 = stick izquierdo, 1 = derecho */
double c3d_fps(void);
double c3d_sample_rate(void);
float c3d_aspect(void);
size_t c3d_audio_pop(int16_t *dst, size_t frames);
size_t c3d_state_size(void);
bool c3d_state_save(void *dst, size_t size);
bool c3d_state_load(const void *src, size_t size);
void *c3d_sram(size_t *size);
const char *c3d_last_error(void);
#endif
