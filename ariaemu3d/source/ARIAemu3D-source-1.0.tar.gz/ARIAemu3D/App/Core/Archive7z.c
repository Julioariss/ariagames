#include "Archive7z.h"
#include "lzma/7z.h"
#include "lzma/7zAlloc.h"
#include "lzma/7zCrc.h"
#include <stdlib.h>
#include <string.h>

typedef struct { ISeekInStream vt; const uint8_t *data; size_t size; size_t pos; } MemStream;
static SRes mem_read(const ISeekInStream *pp, void *buf, size_t *size) {
  MemStream *p = (MemStream *)pp;
  size_t n = *size; if (p->pos + n > p->size) n = p->size - p->pos;
  memcpy(buf, p->data + p->pos, n); p->pos += n; *size = n; return SZ_OK;
}
static SRes mem_seek(const ISeekInStream *pp, Int64 *pos, ESzSeek origin) {
  MemStream *p = (MemStream *)pp;
  Int64 np = origin == SZ_SEEK_SET ? *pos : origin == SZ_SEEK_CUR ? (Int64)p->pos + *pos : (Int64)p->size + *pos;
  if (np < 0 || np > (Int64)p->size) return SZ_ERROR_READ;
  p->pos = (size_t)np; *pos = np; return SZ_OK;
}

int sz7_extract(const void *data, size_t size, void (*cb)(const char *, const uint8_t *, size_t, void *), void *ctx) {
  static int crc_done = 0; if (!crc_done) { CrcGenerateTable(); crc_done = 1; }
  ISzAlloc alloc = { SzAlloc, SzFree }, allocTemp = { SzAllocTemp, SzFreeTemp };
  MemStream ms = { { mem_read, mem_seek }, data, size, 0 };
  CLookToRead2 look; LookToRead2_CreateVTable(&look, False);
  look.buf = (Byte *)malloc(1 << 16); look.bufSize = 1 << 16; look.realStream = &ms.vt; LookToRead2_Init(&look);
  CSzArEx db; SzArEx_Init(&db);
  if (SzArEx_Open(&db, &look.vt, &alloc, &allocTemp) != SZ_OK) { free(look.buf); return -1; }
  UInt32 blockIndex = 0xFFFFFFFF; Byte *outBuf = NULL; size_t outBufSize = 0;
  UInt16 *name16 = NULL; size_t name16cap = 0;
  for (UInt32 i = 0; i < db.NumFiles; i++) {
    if (SzArEx_IsDir(&db, i)) continue;
    size_t offset = 0, outSize = 0;
    if (SzArEx_Extract(&db, &look.vt, i, &blockIndex, &outBuf, &outBufSize, &offset, &outSize, &alloc, &allocTemp) != SZ_OK) continue;
    size_t ln = SzArEx_GetFileNameUtf16(&db, i, NULL);
    if (ln > name16cap) { free(name16); name16 = malloc(ln * 2); name16cap = ln; }
    SzArEx_GetFileNameUtf16(&db, i, name16);
    char name[512]; size_t k = 0;             // UTF-16 → ASCII/UTF-8 simple (nombres de ROM)
    for (size_t j = 0; j < ln && k < sizeof(name) - 4; j++) {
      UInt32 c = name16[j]; if (!c) break;
      if (c < 0x80) name[k++] = (char)c;
      else if (c < 0x800) { name[k++] = 0xC0 | (c >> 6); name[k++] = 0x80 | (c & 63); }
      else { name[k++] = 0xE0 | (c >> 12); name[k++] = 0x80 | ((c >> 6) & 63); name[k++] = 0x80 | (c & 63); }
    }
    name[k] = 0;
    cb(name, outBuf + offset, outSize, ctx);
  }
  ISzAlloc_Free(&alloc, outBuf); free(name16);
  SzArEx_Free(&db, &alloc); free(look.buf);
  return 0;
}
