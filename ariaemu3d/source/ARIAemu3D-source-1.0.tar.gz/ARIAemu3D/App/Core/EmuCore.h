#ifndef EMUCORE_H
#define EMUCORE_H
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
typedef enum { EMU_CORE_N64 = 0, EMU_CORE_PSP = 1, EMU_CORE_COUNT = 2 } EmuCoreKind;
void emu_set_layer(void *layer);
void emu_set_analog(int idx, int16_t x, int16_t y);
float emu_aspect(void);
const char *emu_error(void);
void emu_set_system_dir(const char *path);
bool emu_load(EmuCoreKind kind, const void *data, size_t size, const char *path);
void emu_unload(void);
void emu_reset(void);
void emu_run_frame(void);
void emu_set_buttons(uint32_t mask);
void emu_set_buttons2(uint32_t mask);
void emu_set_video_enabled(bool on);
const uint32_t *emu_framebuffer(unsigned *w, unsigned *h);
double emu_fps(void);
double emu_sample_rate(void);
size_t emu_audio_pop(int16_t *dst, size_t frames);
void *emu_sram(size_t *size);
uint64_t emu_frame_counter(void);
void *emu_sysram(size_t *size);
size_t emu_state_size(void);
bool emu_state_save(void *dst, size_t size);
bool emu_state_load(const void *src, size_t size);
/* Cable link Game Boy (núcleo mGBA, solo iPhone/iPad) */
void aria_link_set_sender(void (*cb)(int kind, int byte));
void aria_link_enable(bool on);
void aria_link_receive(int kind, int byte);
#endif
