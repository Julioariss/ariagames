// ARIAemu 3D — anfitrión libretro con render OpenGL ES 3 (núcleos N64 y PSP cargados como framework dinámico).
// Licencia: GPL-2.0-or-later (ver LICENSE del proyecto).
#import <Foundation/Foundation.h>
#import <OpenGLES/EAGL.h>
#import <OpenGLES/ES3/gl.h>
#import <OpenGLES/ES3/glext.h>
#import <QuartzCore/QuartzCore.h>
#include <dlfcn.h>
#include <stdatomic.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include "libretro.h"
#include "Core3D.h"

typedef struct {
  void *h;
  void (*init)(void); void (*deinit)(void); void (*run)(void); void (*reset)(void);
  bool (*load)(const struct retro_game_info *); void (*unload)(void);
  void (*set_env)(retro_environment_t); void (*set_video)(retro_video_refresh_t);
  void (*set_audio)(retro_audio_sample_t); void (*set_audio_batch)(retro_audio_sample_batch_t);
  void (*set_poll)(retro_input_poll_t); void (*set_input)(retro_input_state_t);
  void (*av_info)(struct retro_system_av_info *); void (*sys_info)(struct retro_system_info *);
  void (*set_port)(unsigned, unsigned);
  void *(*mem_data)(unsigned); size_t (*mem_size)(unsigned);
  size_t (*ser_size)(void); bool (*ser)(void *, size_t); bool (*unser)(const void *, size_t);
} Fn;

#define AUDIO_RING 65536
static struct {
  Fn f; bool loaded; C3DKind kind;
  char sysdir[1024], savedir[1024], err[512];
  EAGLContext *ctx;
  GLuint fbo, tex, depth; unsigned fbw, fbh;      // FBO donde dibuja el núcleo
  GLuint pfbo, prb; GLint pw, ph;                 // FBO de presentación (capa)
  void *layer; _Atomic bool layerDirty;
  struct retro_hw_render_callback hw; bool useHW;
  unsigned lastW, lastH; bool frameHW, haveFrame;
  enum retro_pixel_format fmt; uint8_t *conv; size_t convCap;
  float aspect; double fps, rate;
  _Atomic uint32_t buttons; _Atomic int32_t analog[4];
  int16_t ring[AUDIO_RING * 2]; _Atomic uint32_t wr, rd;
} G;

const char *c3d_last_error(void) { return G.err; }
void c3d_set_dirs(const char *s, const char *v) {
  snprintf(G.sysdir, sizeof G.sysdir, "%s", s ? s : ""); snprintf(G.savedir, sizeof G.savedir, "%s", v ? v : "");
}
void c3d_set_layer(void *layer) { G.layer = layer; atomic_store(&G.layerDirty, true); }

static void log_cb(enum retro_log_level lvl, const char *fmt, ...) {
  va_list ap; va_start(ap, fmt); vfprintf(stderr, fmt, ap); va_end(ap);
}

// Opciones fijas de cada núcleo: sin JIT (App Store) y render compatible con OpenGL ES.
static const char *option(const char *key) {
  static const char *kv[][2] = {
    {"mupen64plus-cpucore", "cached_interpreter"},
    {"mupen64plus-rdp-plugin", "gliden64"},
    {"mupen64plus-rsp-plugin", "hle"},
    {"mupen64plus-43screensize", "640x480"},
    {"mupen64plus-EnableFBEmulation", "True"},
    {"mupen64plus-pak1", "memory"},
    {"ppsspp_cpu_core", "IR JIT"},
    {"ppsspp_internal_resolution", "960x544"},
    {"ppsspp_backend", "opengl"},
    {"ppsspp_fast_memory", "enabled"},
    {"ppsspp_frameskip", "0"},
  };
  for (size_t i = 0; i < sizeof kv / sizeof kv[0]; i++) if (!strcmp(kv[i][0], key)) return kv[i][1];
  return NULL;
}

// Valores por defecto que declara el núcleo (SET_VARIABLES: "Descripción; defecto|otro|...").
#define MAXVARS 256
static char *VK[MAXVARS], *VV[MAXVARS]; static int NV;
static void store_defaults(const struct retro_variable *v) {
  for (int i = 0; i < NV; i++) { free(VK[i]); free(VV[i]); } NV = 0;
  for (; v && v->key && NV < MAXVARS; v++) {
    const char *semi = v->value ? strchr(v->value, ';') : NULL; if (!semi) continue;
    semi++; while (*semi == ' ') semi++;
    const char *bar = strchr(semi, '|'); size_t n = bar ? (size_t)(bar - semi) : strlen(semi);
    VK[NV] = strdup(v->key); VV[NV] = strndup(semi, n); NV++;
  }
}
static const char *default_of(const char *key) { for (int i = 0; i < NV; i++) if (!strcmp(VK[i], key)) return VV[i]; return NULL; }

static uintptr_t get_fb(void) { return G.fbo; }
static retro_proc_address_t get_proc(const char *sym) { return (retro_proc_address_t)dlsym(RTLD_DEFAULT, sym); }

static bool env_cb(unsigned cmd, void *data) {
  switch (cmd) {
    case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT: {
      enum retro_pixel_format f = *(enum retro_pixel_format *)data; G.fmt = f;
      return f == RETRO_PIXEL_FORMAT_RGB565 || f == RETRO_PIXEL_FORMAT_XRGB8888 || f == RETRO_PIXEL_FORMAT_0RGB1555;
    }
    case RETRO_ENVIRONMENT_SET_HW_RENDER: {
      struct retro_hw_render_callback *cb = data;
      if (cb->context_type != RETRO_HW_CONTEXT_OPENGLES2 && cb->context_type != RETRO_HW_CONTEXT_OPENGLES3 &&
          cb->context_type != RETRO_HW_CONTEXT_OPENGLES_VERSION) return false;
      cb->get_current_framebuffer = get_fb; cb->get_proc_address = get_proc;
      G.hw = *cb; G.useHW = true; return true;
    }
    case RETRO_ENVIRONMENT_GET_PREFERRED_HW_RENDER: *(unsigned *)data = RETRO_HW_CONTEXT_OPENGLES3; return true;
    case RETRO_ENVIRONMENT_GET_CAN_DUPE: *(bool *)data = true; return true;
    case RETRO_ENVIRONMENT_GET_INPUT_BITMASKS: return true;
    case RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION: *(unsigned *)data = 0; return true;
    case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY: *(const char **)data = G.sysdir; return true;
    case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY: *(const char **)data = G.savedir; return true;
    case RETRO_ENVIRONMENT_GET_LOG_INTERFACE: ((struct retro_log_callback *)data)->log = log_cb; return true;
    case RETRO_ENVIRONMENT_GET_VARIABLE: {
      struct retro_variable *v = data; const char *val = v && v->key ? option(v->key) : NULL;
      if (!val && v && v->key) val = default_of(v->key);
      if (!val) return false; v->value = val; return true;
    }
    case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE: *(bool *)data = false; return true;
    case RETRO_ENVIRONMENT_SET_GEOMETRY: {
      const struct retro_game_geometry *g = data;
      if (g->aspect_ratio > 0.1f) G.aspect = g->aspect_ratio; else if (g->base_height) G.aspect = (float)g->base_width / g->base_height;
      return true;
    }
    case RETRO_ENVIRONMENT_SET_SYSTEM_AV_INFO: {
      const struct retro_system_av_info *a = data;
      if (a->geometry.aspect_ratio > 0.1f) G.aspect = a->geometry.aspect_ratio;
      return true;
    }
    case RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL:
    case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME:
    case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
    case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
      return true;
    case RETRO_ENVIRONMENT_SET_VARIABLES: store_defaults(data); return true;
    default: return false;
  }
}

// MARK: GL
static void make_core_fbo(unsigned w, unsigned h) {
  if (G.fbo && w <= G.fbw && h <= G.fbh) return;
  if (G.fbo) { glDeleteFramebuffers(1, &G.fbo); glDeleteTextures(1, &G.tex); glDeleteRenderbuffers(1, &G.depth); }
  G.fbw = w; G.fbh = h;
  glGenTextures(1, &G.tex); glBindTexture(GL_TEXTURE_2D, G.tex);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glGenRenderbuffers(1, &G.depth); glBindRenderbuffer(GL_RENDERBUFFER, G.depth);
  glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH24_STENCIL8, w, h);
  glGenFramebuffers(1, &G.fbo); glBindFramebuffer(GL_FRAMEBUFFER, G.fbo);
  glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, G.tex, 0);
  glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL_RENDERBUFFER, G.depth);
  glClearColor(0, 0, 0, 1); glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
}

static void ensure_present(void) {
  if (!atomic_exchange(&G.layerDirty, false) && G.pfbo) return;
  if (G.pfbo) { glDeleteFramebuffers(1, &G.pfbo); glDeleteRenderbuffers(1, &G.prb); G.pfbo = G.prb = 0; }
  if (!G.layer) return;
  glGenRenderbuffers(1, &G.prb); glBindRenderbuffer(GL_RENDERBUFFER, G.prb);
  [G.ctx renderbufferStorage:GL_RENDERBUFFER fromDrawable:(__bridge CAEAGLLayer *)G.layer];
  glGetRenderbufferParameteriv(GL_RENDERBUFFER, GL_RENDERBUFFER_WIDTH, &G.pw);
  glGetRenderbufferParameteriv(GL_RENDERBUFFER, GL_RENDERBUFFER_HEIGHT, &G.ph);
  glGenFramebuffers(1, &G.pfbo); glBindFramebuffer(GL_FRAMEBUFFER, G.pfbo);
  glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_RENDERBUFFER, G.prb);
}

static void present(void) {
  ensure_present();
  if (!G.pfbo || !G.haveFrame || G.pw <= 0 || G.ph <= 0) return;
  glDisable(GL_SCISSOR_TEST); glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
  glBindFramebuffer(GL_DRAW_FRAMEBUFFER, G.pfbo);
  glViewport(0, 0, G.pw, G.ph); glClearColor(0, 0, 0, 1); glClear(GL_COLOR_BUFFER_BIT);
  // La vista ya tiene la proporción de la consola: la imagen ocupa todo el recuadro, sin bordes negros.
  GLint dw = G.pw, dh = G.ph, x0 = 0, y0 = 0;
  glBindFramebuffer(GL_READ_FRAMEBUFFER, G.fbo);
  // HW: origen abajo-izquierda (igual que la capa). SW: filas de arriba hacia abajo → se invierte.
  if (G.frameHW && G.hw.bottom_left_origin) glBlitFramebuffer(0, 0, G.lastW, G.lastH, x0, y0, x0 + dw, y0 + dh, GL_COLOR_BUFFER_BIT, GL_LINEAR);
  else glBlitFramebuffer(0, 0, G.lastW, G.lastH, x0, y0 + dh, x0 + dw, y0, GL_COLOR_BUFFER_BIT, GL_LINEAR);
  glBindRenderbuffer(GL_RENDERBUFFER, G.prb);
  [G.ctx presentRenderbuffer:GL_RENDERBUFFER];
  glBindFramebuffer(GL_FRAMEBUFFER, G.fbo);
}

static void video_cb(const void *d, unsigned w, unsigned h, size_t pitch) {
  if (!d || !w || !h) return;   // cuadro repetido
  G.lastW = w; G.lastH = h; G.haveFrame = true;
  if (d == RETRO_HW_FRAME_BUFFER_VALID) { G.frameHW = true; return; }
  G.frameHW = false;
  make_core_fbo(w > G.fbw ? w : G.fbw, h > G.fbh ? h : G.fbh);
  size_t need = (size_t)w * h * 4;
  if (need > G.convCap) { free(G.conv); G.conv = malloc(need); G.convCap = need; }
  for (unsigned y = 0; y < h; y++) {
    uint8_t *o = G.conv + (size_t)y * w * 4;
    const uint8_t *row = (const uint8_t *)d + y * pitch;
    for (unsigned x = 0; x < w; x++) {
      uint8_t r, g, b;
      if (G.fmt == RETRO_PIXEL_FORMAT_XRGB8888) { uint32_t p = ((const uint32_t *)row)[x]; r = p >> 16; g = p >> 8; b = p; }
      else if (G.fmt == RETRO_PIXEL_FORMAT_RGB565) { uint16_t p = ((const uint16_t *)row)[x]; r = (p >> 11) << 3; g = ((p >> 5) & 63) << 2; b = (p & 31) << 3; }
      else { uint16_t p = ((const uint16_t *)row)[x]; r = ((p >> 10) & 31) << 3; g = ((p >> 5) & 31) << 3; b = (p & 31) << 3; }
      o[x * 4] = r; o[x * 4 + 1] = g; o[x * 4 + 2] = b; o[x * 4 + 3] = 255;
    }
  }
  glBindTexture(GL_TEXTURE_2D, G.tex);
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, G.conv);
}

// MARK: Audio / entrada
static void push_audio(const int16_t *s, size_t frames) {
  uint32_t w = atomic_load_explicit(&G.wr, memory_order_relaxed), r = atomic_load_explicit(&G.rd, memory_order_acquire);
  for (size_t i = 0; i < frames; i++) {
    if (w - r >= AUDIO_RING) break;
    uint32_t idx = (w & (AUDIO_RING - 1)) * 2; G.ring[idx] = s[i * 2]; G.ring[idx + 1] = s[i * 2 + 1]; w++;
  }
  atomic_store_explicit(&G.wr, w, memory_order_release);
}
static void audio_cb(int16_t l, int16_t r) { int16_t s[2] = { l, r }; push_audio(s, 1); }
static size_t audio_batch_cb(const int16_t *d, size_t n) { push_audio(d, n); return n; }
static void poll_cb(void) {}
static int16_t input_cb(unsigned port, unsigned device, unsigned index, unsigned id) {
  if (port != 0) return 0;
  if (device == RETRO_DEVICE_JOYPAD) {
    uint32_t m = atomic_load(&G.buttons);
    if (id == RETRO_DEVICE_ID_JOYPAD_MASK) return (int16_t)(m & 0xFFFF);
    return (m >> id) & 1;
  }
  if (device == RETRO_DEVICE_ANALOG && index <= 1 && id <= 1) return (int16_t)atomic_load(&G.analog[index * 2 + id]);
  return 0;
}

#define SYM(field, name) G.f.field = dlsym(G.f.h, name); if (!G.f.field) { snprintf(G.err, sizeof G.err, "Falta %s", name); return false; }
static bool bind_core(const char *path) {
  G.f.h = dlopen(path, RTLD_NOW | RTLD_LOCAL);
  if (!G.f.h) { snprintf(G.err, sizeof G.err, "%s", dlerror()); return false; }
  SYM(init, "retro_init") SYM(deinit, "retro_deinit") SYM(run, "retro_run") SYM(reset, "retro_reset")
  SYM(load, "retro_load_game") SYM(unload, "retro_unload_game") SYM(set_env, "retro_set_environment")
  SYM(set_video, "retro_set_video_refresh") SYM(set_audio, "retro_set_audio_sample")
  SYM(set_audio_batch, "retro_set_audio_sample_batch") SYM(set_poll, "retro_set_input_poll")
  SYM(set_input, "retro_set_input_state") SYM(av_info, "retro_get_system_av_info") SYM(sys_info, "retro_get_system_info")
  SYM(set_port, "retro_set_controller_port_device")
  SYM(mem_data, "retro_get_memory_data") SYM(mem_size, "retro_get_memory_size")
  SYM(ser_size, "retro_serialize_size") SYM(ser, "retro_serialize") SYM(unser, "retro_unserialize")
  return true;
}

bool c3d_load(C3DKind kind, const char *dylib, const char *rom) {
  c3d_unload();
  G.err[0] = 0; G.kind = kind; G.useHW = false; G.haveFrame = false; G.aspect = 0; G.fmt = RETRO_PIXEL_FORMAT_0RGB1555;
  atomic_store(&G.wr, 0); atomic_store(&G.rd, 0); atomic_store(&G.buttons, 0);
  for (int i = 0; i < 4; i++) atomic_store(&G.analog[i], 0);
  if (!G.ctx) G.ctx = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES3];
  if (!G.ctx || ![EAGLContext setCurrentContext:G.ctx]) { snprintf(G.err, sizeof G.err, "Sin OpenGL ES 3"); return false; }
  if (!bind_core(dylib)) return false;
  G.f.set_env(env_cb);
  G.f.init();
  G.f.set_video(video_cb); G.f.set_audio(audio_cb); G.f.set_audio_batch(audio_batch_cb);
  G.f.set_poll(poll_cb); G.f.set_input(input_cb);
  struct retro_system_info si; memset(&si, 0, sizeof si); G.f.sys_info(&si);
  struct retro_game_info gi = { rom, NULL, 0, NULL };
  NSData *data = nil;
  if (!si.need_fullpath) {
    data = [NSData dataWithContentsOfFile:[NSString stringWithUTF8String:rom]];
    if (!data) { snprintf(G.err, sizeof G.err, "No pude leer el archivo"); G.f.deinit(); return false; }
    gi.data = data.bytes; gi.size = data.length;
  }
  if (!G.f.load(&gi)) { if (!G.err[0]) snprintf(G.err, sizeof G.err, "El núcleo rechazó el juego"); G.f.deinit(); dlclose(G.f.h); G.f.h = NULL; return false; }
  G.f.set_port(0, RETRO_DEVICE_ANALOG);
  struct retro_system_av_info av; memset(&av, 0, sizeof av); G.f.av_info(&av);
  G.fps = av.timing.fps > 1 ? av.timing.fps : 60; G.rate = av.timing.sample_rate > 1000 ? av.timing.sample_rate : 44100;
  if (!(G.aspect > 0.1f)) G.aspect = av.geometry.aspect_ratio > 0.1f ? av.geometry.aspect_ratio : (kind == C3D_PSP ? 480.f / 272.f : 4.f / 3.f);
  unsigned mw = av.geometry.max_width ? av.geometry.max_width : 1024, mh = av.geometry.max_height ? av.geometry.max_height : 1024;
  make_core_fbo(mw < 640 ? 640 : mw, mh < 480 ? 480 : mh);
  if (G.useHW && G.hw.context_reset) G.hw.context_reset();
  glBindFramebuffer(GL_FRAMEBUFFER, G.fbo);
  G.loaded = true;
  [EAGLContext setCurrentContext:nil];   // se usa luego desde el hilo de emulación
  return true;
}

void c3d_unload(void) {
  if (!G.loaded) return;
  [EAGLContext setCurrentContext:G.ctx];
  if (G.useHW && G.hw.context_destroy) G.hw.context_destroy();
  G.f.unload(); G.f.deinit();
  // dlclose no garantiza reinicializar los núcleos: se mantiene cargado (dlopen devuelve el mismo).
  G.loaded = false;
  if (G.fbo) { glDeleteFramebuffers(1, &G.fbo); glDeleteTextures(1, &G.tex); glDeleteRenderbuffers(1, &G.depth); G.fbo = 0; G.fbw = G.fbh = 0; }
  if (G.pfbo) { glDeleteFramebuffers(1, &G.pfbo); glDeleteRenderbuffers(1, &G.prb); G.pfbo = G.prb = 0; }
  [EAGLContext setCurrentContext:nil];
}
void c3d_reset(void) { if (G.loaded) G.f.reset(); }
void c3d_run_frame(bool show) {
  if (!G.loaded) return;
  [EAGLContext setCurrentContext:G.ctx];
  glBindFramebuffer(GL_FRAMEBUFFER, G.fbo);
  G.f.run();
  if (show) present();
}
void c3d_set_buttons(uint32_t m) { atomic_store(&G.buttons, m); }
void c3d_set_analog(int idx, int16_t x, int16_t y) {
  if (idx < 0 || idx > 1) return; atomic_store(&G.analog[idx * 2], x); atomic_store(&G.analog[idx * 2 + 1], y);
}
double c3d_fps(void) { return G.fps; }
double c3d_sample_rate(void) { return G.rate; }
float c3d_aspect(void) { return G.aspect; }
size_t c3d_audio_pop(int16_t *dst, size_t frames) {
  uint32_t r = atomic_load_explicit(&G.rd, memory_order_relaxed), w = atomic_load_explicit(&G.wr, memory_order_acquire);
  uint32_t maxlag = (uint32_t)(G.rate * 0.12), keep = (uint32_t)(G.rate * 0.06);
  if (maxlag > 0 && w - r > maxlag + (uint32_t)frames) r = w - keep - (uint32_t)frames;
  size_t n = 0;
  while (n < frames && r != w) { uint32_t i = (r & (AUDIO_RING - 1)) * 2; dst[n * 2] = G.ring[i]; dst[n * 2 + 1] = G.ring[i + 1]; r++; n++; }
  atomic_store_explicit(&G.rd, r, memory_order_release);
  return n;
}
size_t c3d_state_size(void) { return G.loaded ? G.f.ser_size() : 0; }
bool c3d_state_save(void *d, size_t n) { return G.loaded && n && G.f.ser(d, n); }
bool c3d_state_load(const void *s, size_t n) { return G.loaded && n && G.f.unser(s, n); }
void *c3d_sram(size_t *n) {
  if (!G.loaded) { *n = 0; return NULL; }
  *n = G.f.mem_size(RETRO_MEMORY_SAVE_RAM); return G.f.mem_data(RETRO_MEMORY_SAVE_RAM);
}

// MARK: Interfaz emu_* (la misma que usa la app de ARIAemu)
#include "EmuCore.h"
static bool S_video = true; static uint64_t S_frames;
static char S_sys[1024];
void emu_set_system_dir(const char *p) {
  snprintf(S_sys, sizeof S_sys, "%s", p ? p : "");
  char saves[1100]; snprintf(saves, sizeof saves, "%s/saves", S_sys);
  [[NSFileManager defaultManager] createDirectoryAtPath:[NSString stringWithUTF8String:saves] withIntermediateDirectories:YES attributes:nil error:nil];
  c3d_set_dirs(S_sys, saves);
}
void emu_set_layer(void *l) { c3d_set_layer(l); }
bool emu_load(EmuCoreKind kind, const void *data, size_t size, const char *path) {
  NSString *fw = kind == EMU_CORE_PSP ? @"ppsspp_libretro" : @"mupen64plus_next_libretro";
  NSString *bin = [[[NSBundle mainBundle] privateFrameworksPath] stringByAppendingFormat:@"/%@.framework/%@", fw, fw];
  S_frames = 0;
  return c3d_load(kind == EMU_CORE_PSP ? C3D_PSP : C3D_N64, bin.UTF8String, path);
}
void emu_unload(void) { c3d_unload(); }
void emu_reset(void) { c3d_reset(); }
void emu_run_frame(void) { c3d_run_frame(S_video); S_frames++; }
void emu_set_buttons(uint32_t m) { c3d_set_buttons(m); }
void emu_set_buttons2(uint32_t m) { (void)m; }
void emu_set_analog(int idx, int16_t x, int16_t y) { c3d_set_analog(idx, x, y); }
void emu_set_video_enabled(bool on) { S_video = on; }
const uint32_t *emu_framebuffer(unsigned *w, unsigned *h) { *w = 0; *h = 0; return NULL; }
double emu_fps(void) { return c3d_fps(); }
double emu_sample_rate(void) { return c3d_sample_rate(); }
float emu_aspect(void) { return c3d_aspect(); }
const char *emu_error(void) { return c3d_last_error(); }
size_t emu_audio_pop(int16_t *d, size_t n) { return c3d_audio_pop(d, n); }
void *emu_sram(size_t *n) { return c3d_sram(n); }
uint64_t emu_frame_counter(void) { return S_frames; }
void *emu_sysram(size_t *n) { *n = 0; return NULL; }
size_t emu_state_size(void) { return c3d_state_size(); }
bool emu_state_save(void *d, size_t n) { return c3d_state_save(d, n); }
bool emu_state_load(const void *s, size_t n) { return c3d_state_load(s, n); }
void aria_link_set_sender(void (*cb)(int, int)) { (void)cb; }
void aria_link_enable(bool on) { (void)on; }
void aria_link_receive(int k, int b) { (void)k; (void)b; }
