import SwiftUI
import WebKit

/// Busca la carátula del juego en Google Imágenes dentro de la app.
/// Al tocar una imagen se muestra para confirmar y se guarda como portada.
final class CoverWeb: NSObject, ObservableObject, WKNavigationDelegate, WKScriptMessageHandler {
    let web: WKWebView
    @Published var loading = false
    @Published var picked: UIImage?
    @Published var busy = false

    override init() {
        let cfg = WKWebViewConfiguration()
        let js = """
        (function(){
          function best(img){ var s = img.currentSrc || img.src || ''; return s; }
          document.addEventListener('click', function(e){
            var el = e.target; var img = null;
            for (var i=0; i<6 && el; i++){ if (el.tagName === 'IMG'){ img = el; break; } var q = el.querySelector && el.querySelector('img'); if (q){ img = q; break; } el = el.parentElement; }
            if (!img) return;
            var r = img.getBoundingClientRect(); if (r.width < 60 || r.height < 60) return;
            var big = null; document.querySelectorAll('img').forEach(function(x){ var b=x.getBoundingClientRect(); if (b.width > 200 && x.src && x.src.indexOf('http')===0 && x.src.indexOf('gstatic')<0) big = big || x; });
            window.webkit.messageHandlers.cover.postMessage({src: best(img), big: big ? big.src : ''});
          }, true);
        })();
        """
        cfg.userContentController.addUserScript(WKUserScript(source: js, injectionTime: .atDocumentEnd, forMainFrameOnly: true))
        web = WKWebView(frame: .zero, configuration: cfg)
        super.init()
        cfg.userContentController.add(self, name: "cover")
        web.navigationDelegate = self
        web.allowsBackForwardNavigationGestures = true
    }

    func search(_ title: String) {
        let q = "\(title) cover box art".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        if let u = URL(string: "https://www.google.com/search?tbm=isch&q=\(q)") { web.load(URLRequest(url: u)) }
    }

    func userContentController(_ c: WKUserContentController, didReceive m: WKScriptMessage) {
        guard let d = m.body as? [String: String] else { return }
        // Primero intenta la imagen grande de la vista previa; si no, la miniatura tocada.
        let cands = [d["big"] ?? "", d["src"] ?? ""].filter { !$0.isEmpty }
        Task { await load(cands) }
    }

    @MainActor private func load(_ cands: [String]) async {
        busy = true; defer { busy = false }
        for s in cands {
            if s.hasPrefix("data:image"), let comma = s.firstIndex(of: ","),
               let data = Data(base64Encoded: String(s[s.index(after: comma)...])), let img = UIImage(data: data) { picked = img; return }
            if let u = URL(string: s), let (data, _) = try? await URLSession.shared.data(from: u), let img = UIImage(data: data), img.size.width >= 60 { picked = img; return }
        }
    }

    func webView(_ w: WKWebView, didStartProvisionalNavigation n: WKNavigation!) { loading = true }
    func webView(_ w: WKWebView, didFinish n: WKNavigation!) { loading = false }
    func webView(_ w: WKWebView, didFail n: WKNavigation!, withError e: Error) { loading = false }
}

private struct CoverWebBox: UIViewRepresentable {
    let web: WKWebView
    func makeUIView(context: Context) -> WKWebView { web }
    func updateUIView(_ v: WKWebView, context: Context) {}
}

struct CoverSearchView: View {
    let title: String
    let onPick: (Data) -> Void
    @Environment(\.dismiss) private var dismiss
    @StateObject private var model = CoverWeb()

    var body: some View {
        NavigationStack {
            ZStack {
                CoverWebBox(web: model.web).ignoresSafeArea(edges: .bottom)
                if model.loading || model.busy { ProgressView().controlSize(.large).padding(20).background(.thinMaterial, in: RoundedRectangle(cornerRadius: 14)) }
                VStack {
                    Spacer()
                    Text("Toca la carátula que quieras").font(.footnote.weight(.semibold)).padding(.horizontal, 14).padding(.vertical, 8)
                        .background(.black.opacity(0.7), in: Capsule()).foregroundStyle(.white).padding(.bottom, 18)
                }.allowsHitTesting(false)
            }
            .navigationTitle("Carátula").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Cerrar") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) { Button { model.web.goBack() } label: { Image(systemName: "chevron.backward") }.disabled(!model.web.canGoBack) }
            }
            .onAppear { model.search(title) }
            .sheet(item: Binding(get: { model.picked.map { PickedImage(img: $0) } }, set: { if $0 == nil { model.picked = nil } })) { p in
                VStack(spacing: 18) {
                    Text("¿Usar esta carátula?").font(.title3.weight(.bold)).padding(.top, 22)
                    Image(uiImage: p.img).resizable().scaledToFit().frame(maxHeight: 320).clipShape(RoundedRectangle(cornerRadius: 16))
                        .padding(.horizontal, 24)
                    HStack(spacing: 14) {
                        Button("Elegir otra") { model.picked = nil }.buttonStyle(.bordered).controlSize(.large)
                        Button {
                            if let d = p.img.jpegData(compressionQuality: 0.9) { onPick(d) }
                            UINotificationFeedbackGenerator().notificationOccurred(.success)
                            model.picked = nil; dismiss()
                        } label: { Label("Guardar", systemImage: "checkmark") }.buttonStyle(.borderedProminent).controlSize(.large)
                    }
                    Spacer(minLength: 0)
                }
                .presentationDetents([.medium])
            }
        }
    }
}

private struct PickedImage: Identifiable { let id = UUID(); let img: UIImage }
