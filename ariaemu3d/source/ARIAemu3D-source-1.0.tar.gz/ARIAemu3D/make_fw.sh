#!/bin/zsh
# Envuelve un núcleo libretro .dylib en un .framework embebible (requisito App Store).
# Uso: make_fw.sh <ruta.dylib> <nombre> <destino>
set -e
SRC=$1; N=$2; OUT=$3/$N.framework
rm -rf $OUT; mkdir -p $OUT
cp $SRC $OUT/$N
install_name_tool -id @rpath/$N.framework/$N $OUT/$N
cat > $OUT/Info.plist <<P
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>$N</string>
<key>CFBundleIdentifier</key><string>com.julioaris.ariaemu3d.$(echo $N | tr '_' '-')</string>
<key>CFBundleName</key><string>$N</string>
<key>CFBundlePackageType</key><string>FMWK</string>
<key>CFBundleShortVersionString</key><string>1.0</string>
<key>CFBundleVersion</key><string>1</string>
<key>MinimumOSVersion</key><string>18.0</string>
<key>CFBundleSupportedPlatforms</key><array><string>iPhoneOS</string></array>
</dict></plist>
P
echo "$OUT"
