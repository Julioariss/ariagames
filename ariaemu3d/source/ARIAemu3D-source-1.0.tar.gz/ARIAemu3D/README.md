# ARIAemu 3D

Free, non-commercial, open-source emulator front-end for iPhone and iPad (64-bit and portable 3D consoles).
No games included. Licensed under the GNU GPL v2 or later (see LICENSE).

## Contents
- `App/` — SwiftUI app and the libretro host (`App/Core/Core3D.m`, OpenGL ES 3).
- `patches/` — changes applied to the cores, with the upstream commit each one is based on:
  - Mupen64Plus-Next — https://github.com/libretro/mupen64plus-libretro-nx (GPL-2.0)
  - PPSSPP — https://github.com/hrydgard/ppsspp (GPL-2.0-or-later)
- `make_fw.sh`, `project.yml` — build scripts (xcodegen).

## Build
1. Clone both cores at the commits in `patches/*.commit` and apply `patches/*.patch`.
2. Mupen64Plus-Next: `make platform=ios-arm64`. PPSSPP: `cd libretro && make platform=ios-arm64 TARGET_ARCH=arm64`.
3. Wrap each dylib with `make_fw.sh` into `Frameworks/`, run `xcodegen`, build with Xcode.
